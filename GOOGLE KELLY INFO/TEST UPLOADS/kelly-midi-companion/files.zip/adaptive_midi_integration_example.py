"""
Integration Example: Tempo/Key Adaptive MIDI Generation
Shows how to wire adaptive parameters into existing Kelly system.
"""

from kellymidicompanion_tempo_key_adapter import (
    generate_adaptive_parameters,
    should_regenerate_midi,
    classify_tempo,
    TempoClass
)
from kellymidicompanion_emotion_api import MusicBrain, emotion_to_valence_arousal
from kellymidicompanion_emotional_mapping import EmotionalState, get_parameters_for_state
from typing import Optional, Dict, List
import mido


class AdaptiveMIDIGenerator:
    """MIDI generator with tempo/key adaptation."""
    
    def __init__(self):
        self.brain = MusicBrain()
        self.current_bpm = None
        self.current_key = None
        self.current_mode = None
        self.emotion = None
    
    def generate_adaptive_midi(
        self,
        emotion: str,
        locked_bpm: Optional[int] = None,
        locked_key: Optional[str] = None,
        locked_mode: Optional[str] = None,
        chord_progression: Optional[List[str]] = None,
        output_path: str = "output.mid"
    ) -> Dict:
        """
        Generate MIDI that adapts to locked tempo/key parameters.
        
        Args:
            emotion: Target emotion
            locked_bpm: User-locked tempo (None = use emotion suggestion)
            locked_key: User-locked key (None = use emotion suggestion)
            locked_mode: User-locked mode (None = use emotion suggestion)
            chord_progression: Chord sequence
            output_path: Output file path
        
        Returns:
            Dict with generation metadata
        """
        # Get emotion's natural parameters
        valence, arousal = emotion_to_valence_arousal(emotion)
        state = EmotionalState(
            valence=valence,
            arousal=arousal,
            primary_emotion=emotion
        )
        suggested = get_parameters_for_state(state)
        
        # Determine final parameters
        final_bpm = locked_bpm or suggested.tempo_suggested
        final_key = locked_key or suggested.key_suggested
        final_mode = locked_mode or suggested.mode_suggested
        
        # Generate adaptive parameters
        adapted = generate_adaptive_parameters(
            emotion=emotion,
            locked_bpm=locked_bpm,
            locked_key=locked_key,
            locked_mode=locked_mode,
            suggested_bpm=suggested.tempo_suggested,
            suggested_key=suggested.key_suggested,
            suggested_mode=suggested.mode_suggested
        )
        
        # Apply adaptations to MIDI generation
        midi = self._create_adapted_midi(
            emotion=emotion,
            bpm=final_bpm,
            key=final_key,
            mode=final_mode,
            chord_progression=chord_progression or ["Am", "F", "C", "G"],
            adapted_params=adapted,
            output_path=output_path
        )
        
        # Store current state
        self.current_bpm = final_bpm
        self.current_key = final_key
        self.current_mode = final_mode
        self.emotion = emotion
        
        return {
            "emotion": emotion,
            "bpm": final_bpm,
            "key": final_key,
            "mode": final_mode,
            "suggested_bpm": suggested.tempo_suggested,
            "suggested_key": suggested.key_suggested,
            "tempo_class": classify_tempo(final_bpm).value,
            "adaptations_applied": {
                "note_density": adapted.note_density,
                "articulation": adapted.articulation_length,
                "syncopation": adapted.syncopation_amount,
                "register_shift": adapted.register_shift,
                "chord_complexity": adapted.harmonic_complexity
            },
            "midi_path": output_path
        }
    
    def update_parameters(
        self,
        new_bpm: Optional[int] = None,
        new_key: Optional[str] = None,
        new_mode: Optional[str] = None,
        output_path: str = "updated_output.mid"
    ) -> Optional[Dict]:
        """
        Update MIDI when user changes tempo/key.
        Only regenerates if changes cross emotional threshold.
        
        Returns:
            New generation metadata if regenerated, None if no change needed
        """
        if not self.emotion:
            raise ValueError("No previous generation to update")
        
        # Check if regeneration needed
        needs_regen = should_regenerate_midi(
            current_bpm=self.current_bpm,
            current_key=self.current_key,
            current_mode=self.current_mode,
            new_bpm=new_bpm,
            new_key=new_key,
            new_mode=new_mode
        )
        
        if not needs_regen:
            return None
        
        # Regenerate with new locked parameters
        return self.generate_adaptive_midi(
            emotion=self.emotion,
            locked_bpm=new_bpm or self.current_bpm,
            locked_key=new_key or self.current_key,
            locked_mode=new_mode or self.current_mode,
            output_path=output_path
        )
    
    def _create_adapted_midi(
        self,
        emotion: str,
        bpm: int,
        key: str,
        mode: str,
        chord_progression: List[str],
        adapted_params,
        output_path: str
    ) -> mido.MidiFile:
        """Create MIDI with adapted parameters."""
        mid = mido.MidiFile()
        track = mido.MidiTrack()
        mid.tracks.append(track)
        
        # Set tempo
        tempo = mido.bpm2tempo(bpm)
        track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=0))
        
        # Set time signature
        track.append(mido.MetaMessage('time_signature', numerator=4, denominator=4, time=0))
        
        # Set key signature
        key_map = {'C': 0, 'G': 1, 'D': 2, 'A': 3, 'E': 4, 'B': 5, 
                   'F': -1, 'Bb': -2, 'Eb': -3, 'Ab': -4, 'Db': -5}
        key_num = key_map.get(key, 0)
        track.append(mido.MetaMessage('key_signature', key=key_num, mode=mode, time=0))
        
        # Calculate note timing based on adapted density
        ticks_per_beat = mid.ticks_per_beat
        base_notes_per_bar = 4  # Quarter notes
        notes_per_bar = int(base_notes_per_bar * adapted_params.note_density)
        ticks_per_note = (ticks_per_beat * 4) // notes_per_bar
        
        # Generate notes with adaptations
        current_time = 0
        for bar in range(4):  # 4 bars
            chord = chord_progression[bar % len(chord_progression)]
            
            # Chord notes (simplified - would use real chord parsing)
            root_notes = self._chord_to_notes(chord, key, adapted_params.register_shift)
            
            for note_idx in range(notes_per_bar):
                # Apply syncopation
                if adapted_params.syncopation_amount > 1.0 and note_idx % 2 == 1:
                    # Accent off-beats
                    velocity = int(80 * adapted_params.velocity_variance)
                else:
                    velocity = int(70 * adapted_params.velocity_variance)
                
                # Note duration based on articulation
                duration = int(ticks_per_note * adapted_params.articulation_length)
                
                # Add note
                for note_pitch in root_notes:
                    track.append(mido.Message('note_on', note=note_pitch, velocity=velocity, time=current_time))
                    track.append(mido.Message('note_off', note=note_pitch, velocity=0, time=duration))
                    current_time = 0  # Only first note has time offset
                
                current_time = ticks_per_note - duration
        
        mid.save(output_path)
        return mid
    
    def _chord_to_notes(self, chord: str, key: str, register_shift: int) -> List[int]:
        """Convert chord symbol to MIDI notes (simplified)."""
        # Simplified chord parsing - would use full chord library
        base_notes = {
            'C': 60, 'D': 62, 'E': 64, 'F': 65, 'G': 67, 'A': 69, 'B': 71,
            'Am': 69, 'Dm': 62, 'Em': 64, 'Fm': 65
        }
        root = base_notes.get(chord, 60) + register_shift
        return [root, root + 4, root + 7]  # Simple triad


# ============================================================
# USAGE EXAMPLES
# ============================================================

def example_1_grief_at_different_tempos():
    """Example: Grief emotion at 60 BPM vs 160 BPM."""
    generator = AdaptiveMIDIGenerator()
    
    # Grief at natural tempo (system suggests ~70 BPM)
    result_natural = generator.generate_adaptive_midi(
        emotion="grief",
        output_path="grief_natural.mid"
    )
    print("Grief at natural tempo:")
    print(f"  BPM: {result_natural['bpm']}")
    print(f"  Note density: {result_natural['adaptations_applied']['note_density']:.2f}")
    print()
    
    # Grief locked to 160 BPM (sounds like anxiety, not grief)
    result_fast = generator.generate_adaptive_midi(
        emotion="grief",
        locked_bpm=160,
        output_path="grief_fast.mid"
    )
    print("Grief locked to 160 BPM (becomes anxious):")
    print(f"  BPM: {result_fast['bpm']}")
    print(f"  Note density: {result_fast['adaptations_applied']['note_density']:.2f}")
    print(f"  Syncopation: {result_fast['adaptations_applied']['syncopation']:.2f}")
    print()


def example_2_joy_in_dark_key():
    """Example: Joy emotion in F# minor (dark key)."""
    generator = AdaptiveMIDIGenerator()
    
    # Joy at natural key (system suggests G major)
    result_natural = generator.generate_adaptive_midi(
        emotion="joy",
        output_path="joy_natural.mid"
    )
    print("Joy in natural key:")
    print(f"  Key: {result_natural['key']} {result_natural['mode']}")
    print(f"  Register shift: {result_natural['adaptations_applied']['register_shift']}")
    print()
    
    # Joy locked to F# minor (becomes defiant/bittersweet)
    result_dark = generator.generate_adaptive_midi(
        emotion="joy",
        locked_key="F#",
        locked_mode="minor",
        output_path="joy_dark.mid"
    )
    print("Joy locked to F# minor (becomes defiant):")
    print(f"  Key: {result_dark['key']} {result_dark['mode']}")
    print(f"  Register shift: {result_dark['adaptations_applied']['register_shift']}")
    print(f"  Chord complexity: {result_dark['adaptations_applied']['chord_complexity']}")
    print()


def example_3_dynamic_updates():
    """Example: Update MIDI as user adjusts parameters."""
    generator = AdaptiveMIDIGenerator()
    
    # Initial generation
    result = generator.generate_adaptive_midi(
        emotion="sad",
        output_path="sad_v1.mid"
    )
    print(f"Initial: {result['bpm']} BPM, {result['key']} {result['mode']}")
    
    # User changes tempo slightly - no regeneration needed
    result = generator.update_parameters(
        new_bpm=result['bpm'] + 5,
        output_path="sad_v2.mid"
    )
    if result is None:
        print("No regeneration needed for small tempo change")
    
    # User changes tempo significantly - regenerate
    result = generator.update_parameters(
        new_bpm=140,
        output_path="sad_v3.mid"
    )
    if result:
        print(f"Regenerated: {result['bpm']} BPM (tempo class changed)")
    
    # User changes key - always regenerate
    result = generator.update_parameters(
        new_key="C#",
        new_mode="minor",
        output_path="sad_v4.mid"
    )
    if result:
        print(f"Regenerated: {result['key']} {result['mode']} (key changed)")


def example_4_when_i_found_you_sleeping():
    """Example: Your specific song with locked parameters."""
    generator = AdaptiveMIDIGenerator()
    
    result = generator.generate_adaptive_midi(
        emotion="grief",
        locked_bpm=82,
        locked_key="F",
        locked_mode="major",
        chord_progression=["F", "C", "Dm", "Bbm"],
        output_path="when_i_found_you_sleeping.mid"
    )
    
    print("When I Found You Sleeping:")
    print(f"  Emotion: {result['emotion']}")
    print(f"  BPM: {result['bpm']} (locked)")
    print(f"  Key: {result['key']} {result['mode']} (locked)")
    print(f"  System suggested: {result['suggested_bpm']} BPM, {result['suggested_key']}")
    print(f"  Tempo class: {result['tempo_class']}")
    print(f"  Adaptations:")
    print(f"    Note density: {result['adaptations_applied']['note_density']:.2f}")
    print(f"    Register shift: {result['adaptations_applied']['register_shift']}")


if __name__ == "__main__":
    print("=" * 60)
    print("TEMPO/KEY ADAPTIVE MIDI GENERATION EXAMPLES")
    print("=" * 60)
    print()
    
    example_1_grief_at_different_tempos()
    print("-" * 60)
    example_2_joy_in_dark_key()
    print("-" * 60)
    example_3_dynamic_updates()
    print("-" * 60)
    example_4_when_i_found_you_sleeping()
