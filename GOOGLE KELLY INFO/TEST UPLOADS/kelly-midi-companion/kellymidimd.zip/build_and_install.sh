#!/bin/bash

# Kelly MIDI Companion - Build & Install Script
# Builds plugin, installs to system, and bypasses macOS Gatekeeper

set -e  # Exit on any error

echo "🎸 Kelly MIDI Companion - Build & Install"
echo "=========================================="
echo ""

# Project directory
PROJECT_DIR="$HOME/Desktop/Kelly/kelly str"
cd "$PROJECT_DIR"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Step 1: Build
echo "📦 Building plugin..."
if cmake --build build --config Release -j8; then
    echo -e "${GREEN}✅ Build successful${NC}"
else
    echo -e "${RED}❌ Build failed${NC}"
    exit 1
fi

echo ""

# Step 2: Create plugin directories if they don't exist
echo "📁 Creating plugin directories..."
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3"
mkdir -p "$HOME/Library/Audio/Plug-Ins/CLAP"
echo -e "${GREEN}✅ Directories ready${NC}"

echo ""

# Step 3: Copy VST3
echo "📋 Installing VST3 plugin..."
if [ -d "build/KellyPlugin_artefacts/Release/VST3/Kelly MIDI Companion.vst3" ]; then
    cp -r "build/KellyPlugin_artefacts/Release/VST3/Kelly MIDI Companion.vst3" \
          "$HOME/Library/Audio/Plug-Ins/VST3/"
    echo -e "${GREEN}✅ VST3 copied${NC}"
else
    echo -e "${YELLOW}⚠️  VST3 not found (this is OK if you only built CLAP)${NC}"
fi

echo ""

# Step 4: Copy CLAP
echo "📋 Installing CLAP plugin..."
if [ -d "build/KellyPlugin_artefacts/Release/CLAP/Kelly MIDI Companion.clap" ]; then
    cp -r "build/KellyPlugin_artefacts/Release/CLAP/Kelly MIDI Companion.clap" \
          "$HOME/Library/Audio/Plug-Ins/CLAP/"
    echo -e "${GREEN}✅ CLAP copied${NC}"
else
    echo -e "${YELLOW}⚠️  CLAP not found (this is OK if you only built VST3)${NC}"
fi

echo ""

# Step 5: Code sign VST3 (bypass Gatekeeper)
echo "🔐 Code signing VST3..."
if [ -d "$HOME/Library/Audio/Plug-Ins/VST3/Kelly MIDI Companion.vst3" ]; then
    codesign --force --deep --sign - "$HOME/Library/Audio/Plug-Ins/VST3/Kelly MIDI Companion.vst3"
    echo -e "${GREEN}✅ VST3 signed${NC}"
fi

echo ""

# Step 6: Code sign CLAP (bypass Gatekeeper)
echo "🔐 Code signing CLAP..."
if [ -d "$HOME/Library/Audio/Plug-Ins/CLAP/Kelly MIDI Companion.clap" ]; then
    codesign --force --deep --sign - "$HOME/Library/Audio/Plug-Ins/CLAP/Kelly MIDI Companion.clap"
    echo -e "${GREEN}✅ CLAP signed${NC}"
fi

echo ""

# Step 7: Remove quarantine flags
echo "🧹 Removing quarantine flags..."
if [ -d "$HOME/Library/Audio/Plug-Ins/VST3/Kelly MIDI Companion.vst3" ]; then
    xattr -cr "$HOME/Library/Audio/Plug-Ins/VST3/Kelly MIDI Companion.vst3" 2>/dev/null || true
    echo -e "${GREEN}✅ VST3 quarantine removed${NC}"
fi

if [ -d "$HOME/Library/Audio/Plug-Ins/CLAP/Kelly MIDI Companion.clap" ]; then
    xattr -cr "$HOME/Library/Audio/Plug-Ins/CLAP/Kelly MIDI Companion.clap" 2>/dev/null || true
    echo -e "${GREEN}✅ CLAP quarantine removed${NC}"
fi

echo ""
echo "=========================================="
echo -e "${GREEN}🎉 Kelly MIDI Companion installed successfully!${NC}"
echo ""
echo "Plugins installed to:"
echo "  VST3: ~/Library/Audio/Plug-Ins/VST3/"
echo "  CLAP: ~/Library/Audio/Plug-Ins/CLAP/"
echo ""
echo "Ready to test in:"
echo "  • Logic Pro X"
echo "  • Ableton Live"
echo "  • FL Studio"
echo "  • Reaper"
echo ""
echo "To launch Logic Pro X:"
echo "  open -a 'Logic Pro X'"
echo ""
