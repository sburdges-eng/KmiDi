# Kelly MIDI Companion - Setup Instructions

## 🚀 Quick Start

### Step 1: Copy Build Script to Your Project

```bash
# Navigate to your project
cd ~/Desktop/Kelly/kelly\ str

# Download and install the build script
curl -o build_and_install.sh [URL_TO_SCRIPT]
chmod +x build_and_install.sh
```

**OR manually create it:**
(See build_and_install.sh file provided)

---

### Step 2: Set Up Cursor IDE

#### Option A: Copy .cursorrules to project root
```bash
cd ~/Desktop/Kelly/kelly\ str
# Copy the .cursorrules file to project root
```

#### Option B: Copy tasks.json to .vscode folder
```bash
cd ~/Desktop/Kelly/kelly\ str
mkdir -p .vscode
# Copy tasks.json to .vscode/tasks.json
```

---

### Step 3: Build & Install

**From Terminal:**
```bash
~/Desktop/Kelly/kelly\ str/build_and_install.sh
```

**From Cursor:**
- Press `Cmd+Shift+B` (Run Build Task)
- Select "Kelly: Build & Install"

---

## 📋 All Available Commands

### Main Build Script
```bash
# Does everything: build, install, sign, remove quarantine
~/Desktop/Kelly/kelly\ str/build_and_install.sh
```

### Manual Commands

**Build only:**
```bash
cd ~/Desktop/Kelly/kelly\ str
cmake --build build --config Release -j8
```

**Install plugins:**
```bash
cp -r build/KellyPlugin_artefacts/Release/VST3/Kelly\ MIDI\ Companion.vst3 \
      ~/Library/Audio/Plug-Ins/VST3/
```

**Code sign (bypass Gatekeeper):**
```bash
codesign --force --deep --sign - ~/Library/Audio/Plug-Ins/VST3/Kelly\ MIDI\ Companion.vst3
```

**Remove quarantine:**
```bash
xattr -cr ~/Library/Audio/Plug-Ins/VST3/Kelly\ MIDI\ Companion.vst3
```

---

## 🎹 Cursor Tasks

Once tasks.json is in `.vscode/tasks.json`, you can:

### Run from Command Palette
1. Press `Cmd+Shift+P`
2. Type "Tasks: Run Task"
3. Select task:
   - **Kelly: Build & Install** (recommended - does everything)
   - **Kelly: Build Only** (just compile, no install)
   - **Kelly: Clean Build** (start fresh)
   - **Kelly: Code Sign Plugins** (just sign)
   - **Kelly: Launch Logic Pro X**
   - **Kelly: Test Python Bridge**

### Keyboard Shortcut
- `Cmd+Shift+B` → Runs default build task (Build & Install)

---

## 🔧 What the Build Script Does

1. ✅ Builds the plugin with CMake
2. ✅ Creates plugin directories if needed
3. ✅ Copies VST3 to ~/Library/Audio/Plug-Ins/VST3/
4. ✅ Copies CLAP to ~/Library/Audio/Plug-Ins/CLAP/
5. ✅ Code signs both plugins (bypasses Gatekeeper)
6. ✅ Removes quarantine flags
7. ✅ Shows success message with next steps

**You never have to manually bypass Gatekeeper again!**

---

## 🐛 Troubleshooting

### Build fails
```bash
# Try clean build
cd ~/Desktop/Kelly/kelly\ str
rm -rf build
cmake -B build -DBUILD_PLUGINS=ON
cmake --build build --config Release -j8
```

### Plugin won't load in DAW
```bash
# Re-sign the plugin
codesign --force --deep --sign - ~/Library/Audio/Plug-Ins/VST3/Kelly\ MIDI\ Companion.vst3

# Remove quarantine
xattr -cr ~/Library/Audio/Plug-Ins/VST3/Kelly\ MIDI\ Companion.vst3

# Rescan plugins in your DAW
```

### Python import fails
```bash
# Test Python imports
python3 -c "import sys; sys.path.insert(0, '/Users/seanburdges/Desktop/Kelly/kelly str'); import kellymidicompanion_intent_processor; print('✅ Works!')"
```

### "Permission denied" when running script
```bash
chmod +x ~/Desktop/Kelly/kelly\ str/build_and_install.sh
```

---

## 📂 File Locations

**Your project:**
```
~/Desktop/Kelly/kelly str/
├── build_and_install.sh       ← Main build script
├── .cursorrules                ← Cursor IDE rules
├── .vscode/
│   └── tasks.json              ← Cursor tasks
├── build/                      ← Build output
└── src/                        ← Source code
```

**Installed plugins:**
```
~/Library/Audio/Plug-Ins/
├── VST3/
│   └── Kelly MIDI Companion.vst3
└── CLAP/
    └── Kelly MIDI Companion.clap
```

---

## 🎸 Development Workflow

**The Loop:**
1. Edit code in Cursor
2. Press `Cmd+Shift+B` (or run build script)
3. Open Logic Pro X: `open -a "Logic Pro X"`
4. Test plugin
5. Repeat

**Every time you build, the script automatically:**
- Compiles
- Installs
- Signs (no more Gatekeeper prompts!)
- Cleans quarantine

---

## ✅ Success Checklist

After setup, you should be able to:
- [ ] Run `build_and_install.sh` from terminal
- [ ] Press `Cmd+Shift+B` in Cursor to build
- [ ] Load plugin in Logic Pro X without Gatekeeper warnings
- [ ] See "Kelly MIDI Companion" in Logic's plugin list
- [ ] Plugin loads without crashes

---

## 🚨 The ONE Command You Need

**Just run this every time you make changes:**

```bash
~/Desktop/Kelly/kelly\ str/build_and_install.sh
```

That's it. Everything else is handled.

---

## 📝 Notes

- Script uses ad-hoc signing (dash after `--sign`)
- This is fine for development
- For distribution, you'll need a Developer ID
- Quarantine removal only needed for local builds
- App Store builds won't have this issue

**Happy building!** 🎉
