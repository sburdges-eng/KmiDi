"""
Kelly MIDI Companion - Main Orchestrator

The heart of the system. Kelly takes an emotion and key,
then generates a complete musical idea: progression, voicings,
melody, rhythm, and exports to MIDI.

Usage:
    from kellymidicompanion import Kelly

    kelly = Kelly()
    composition = kelly.compose(
        emotion="grief",
        key="F",
        length=4,
        include_melody=True,
        include_drums=False
    )
    composition.export("grief_piece.mid")
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import random

from .voice_leading import VoiceLeadingEngine, VoiceLeadingOutput, VoicedChord, midi_to_note_name
from .progression import ProgressionEngine, ProgressionOutput
from .melody import MelodyEngine, MelodyOutput
from .rhythm import RhythmEngine, RhythmPattern, DrumPattern
from .midi_export import MidiExporter, MidiWriter, TICKS_PER_BEAT


@dataclass
class Composition:
    """Complete musical composition."""
    key: str
    emotion: str
    tempo: int
    time_signature: Tuple[int, int]
    
    # Components
    progression: ProgressionOutput
    voicing: VoiceLeadingOutput
    melody: Optional[MelodyOutput]
    rhythm: Optional[RhythmPattern]
    drums: Optional[DrumPattern]
    bass_line: Optional[List[Dict]]
    
    # Metadata
    seed: Optional[int]
    beats_per_chord: float
    total_bars: int

    def get_chord_symbols(self) -> List[str]:
        """Get list of chord symbols."""
        return self.progression.chords

    def get_voiced_pitches(self) -> List[List[int]]:
        """Get pitches for each voiced chord."""
        return [vc.get_pitches() for vc in self.voicing.voiced_chords]

    def export(self, filename: str) -> str:
        """Export to MIDI file."""
        exporter = MidiExporter()
        exporter.export_full_composition(
            voiced_chords=self.voicing.voiced_chords,
            melody_output=self.melody,
            drum_pattern=self.drums,
            bass_notes=self.bass_line,
            tempo=self.tempo,
            beats_per_chord=self.beats_per_chord,
            filename=filename
        )
        return filename

    def export_chords_only(self, filename: str) -> str:
        """Export just the chord progression."""
        exporter = MidiExporter()
        exporter.export_voiced_progression(
            self.voicing.voiced_chords,
            self.tempo,
            self.beats_per_chord,
            filename=filename
        )
        return filename

    def export_melody_only(self, filename: str) -> str:
        """Export just the melody."""
        if not self.melody:
            raise ValueError("No melody in this composition")
        exporter = MidiExporter()
        exporter.export_melody(self.melody, self.tempo, filename=filename)
        return filename

    def summary(self) -> str:
        """Get text summary of composition."""
        lines = [
            f"=== Kelly Composition ===",
            f"Emotion: {self.emotion}",
            f"Key: {self.key}",
            f"Tempo: {self.tempo} BPM",
            f"Time: {self.time_signature[0]}/{self.time_signature[1]}",
            f"",
            f"Progression: {' → '.join(self.progression.chords)}",
            f"",
            f"Voicings ({self.voicing.voicing_style_used.value}):",
        ]
        
        for vc in self.voicing.voiced_chords:
            pitches = [midi_to_note_name(v.pitch) for v in vc.voices]
            lines.append(f"  {vc.symbol}: {', '.join(pitches)}")
        
        lines.append(f"")
        lines.append(f"Voice leading smoothness: {self.voicing.smoothness_score:.2f}")
        
        if self.melody:
            lines.append(f"Melody: {len(self.melody.notes)} notes, {self.melody.contour.value} contour")
        
        if self.drums:
            lines.append(f"Drums: {self.drums.tempo} BPM, {self.drums.time_signature.value[0]}/{self.drums.time_signature.value[1]}")
        
        return "\n".join(lines)

    def __str__(self) -> str:
        return self.summary()


class Kelly:
    """
    Kelly MIDI Companion - Emotion-to-music generator.
    
    Kelly understands that music is emotional architecture.
    Give her a feeling, and she'll give you notes.
    """

    SUPPORTED_EMOTIONS = [
        "grief", "hope", "rage", "fear", "joy", "longing",
        "anxiety", "tenderness", "defiance", "melancholy",
        "nostalgia", "euphoria", "dissociation", "neutral"
    ]

    def __init__(self, seed: Optional[int] = None):
        self.progression_engine = ProgressionEngine()
        self.voice_leading_engine = VoiceLeadingEngine()
        self.melody_engine = MelodyEngine()
        self.rhythm_engine = RhythmEngine()
        self.default_seed = seed

    def compose(
        self,
        emotion: str = "neutral",
        key: str = "C",
        length: int = 4,
        tempo: Optional[int] = None,
        beats_per_chord: float = 4.0,
        num_voices: int = 4,
        include_melody: bool = True,
        include_rhythm: bool = False,
        include_drums: bool = False,
        include_bass: bool = False,
        seed: Optional[int] = None
    ) -> Composition:
        """
        Generate a complete composition.
        
        Args:
            emotion: Emotional character (grief, hope, rage, etc.)
            key: Musical key (C, F#, Bb, etc.)
            length: Number of chords in progression
            tempo: BPM (auto-selected if None)
            beats_per_chord: Duration of each chord
            num_voices: Voices in chord voicing (3-5)
            include_melody: Generate melody line
            include_rhythm: Generate rhythm pattern
            include_drums: Generate drum pattern
            include_bass: Generate bass line
            seed: Random seed for reproducibility
        
        Returns:
            Composition object
        """
        seed = seed or self.default_seed
        if seed is not None:
            random.seed(seed)

        emotion = emotion.lower()
        if emotion not in self.SUPPORTED_EMOTIONS:
            emotion = "neutral"

        # Generate chord progression
        progression = self.progression_engine.generate(
            key=key,
            emotion=emotion,
            length=length,
            seed=seed
        )

        # Auto-select tempo from emotion profile if not provided
        if tempo is None:
            tempo = random.randint(*progression.tempo_suggestion)

        # Voice the progression
        voicing = self.voice_leading_engine.voice_progression(
            chords=progression.chords,
            key=key,
            emotion=emotion,
            num_voices=num_voices,
            seed=seed
        )

        # Optional melody
        melody = None
        if include_melody:
            melody = self.melody_engine.generate(
                chords=progression.chords,
                key=key,
                emotion=emotion,
                beats_per_chord=beats_per_chord,
                seed=seed
            )

        # Optional rhythm
        rhythm = None
        if include_rhythm:
            rhythm = self.rhythm_engine.generate(
                emotion=emotion,
                num_bars=length,
                seed=seed
            )

        # Optional drums
        drums = None
        if include_drums:
            drums = self.rhythm_engine.generate_drum_pattern(
                emotion=emotion,
                num_bars=length,
                seed=seed
            )

        # Optional bass line (derived from voicing)
        bass_line = None
        if include_bass:
            bass_line = self._generate_bass_line(
                voicing.voiced_chords,
                beats_per_chord,
                emotion
            )

        return Composition(
            key=key,
            emotion=emotion,
            tempo=tempo,
            time_signature=(4, 4),
            progression=progression,
            voicing=voicing,
            melody=melody,
            rhythm=rhythm,
            drums=drums,
            bass_line=bass_line,
            seed=seed,
            beats_per_chord=beats_per_chord,
            total_bars=length
        )

    def _generate_bass_line(self, voiced_chords: List[VoicedChord],
                            beats_per_chord: float, emotion: str) -> List[Dict]:
        """Generate simple bass line from chord roots."""
        bass_notes = []
        time = 0.0

        for vc in voiced_chords:
            # Root note, dropped to bass register
            root_pitch = vc.bass_note
            while root_pitch > 48:
                root_pitch -= 12

            bass_notes.append({
                "pitch": root_pitch,
                "start": time,
                "duration": beats_per_chord * 0.9,
                "velocity": 85
            })

            time += beats_per_chord

        return bass_notes

    def reharmonize(self, composition: Composition,
                    target_emotion: str) -> Composition:
        """Reharmonize existing composition with new emotion."""
        return self.compose(
            emotion=target_emotion,
            key=composition.key,
            length=len(composition.progression.chords),
            tempo=composition.tempo,
            beats_per_chord=composition.beats_per_chord,
            include_melody=composition.melody is not None,
            include_drums=composition.drums is not None
        )

    def extend(self, composition: Composition, bars: int = 4) -> Composition:
        """Extend composition with more bars."""
        return self.compose(
            emotion=composition.emotion,
            key=composition.key,
            length=composition.total_bars + bars,
            tempo=composition.tempo,
            beats_per_chord=composition.beats_per_chord,
            include_melody=composition.melody is not None,
            include_drums=composition.drums is not None,
            seed=composition.seed
        )

    def quick_grief(self, key: str = "F") -> Composition:
        """Quick grief composition."""
        return self.compose(emotion="grief", key=key, length=4)

    def quick_hope(self, key: str = "C") -> Composition:
        """Quick hope composition."""
        return self.compose(emotion="hope", key=key, length=4)

    def quick_rage(self, key: str = "E") -> Composition:
        """Quick rage composition."""
        return self.compose(emotion="rage", key=key, length=4, include_drums=True)


# Convenience functions
def compose(emotion: str = "neutral", key: str = "C", **kwargs) -> Composition:
    """Quick composition."""
    return Kelly().compose(emotion=emotion, key=key, **kwargs)


def grief(key: str = "F") -> Composition:
    """Generate grief piece."""
    return Kelly().quick_grief(key)


def hope(key: str = "C") -> Composition:
    """Generate hope piece."""
    return Kelly().quick_hope(key)


def rage(key: str = "E") -> Composition:
    """Generate rage piece."""
    return Kelly().quick_rage(key)
