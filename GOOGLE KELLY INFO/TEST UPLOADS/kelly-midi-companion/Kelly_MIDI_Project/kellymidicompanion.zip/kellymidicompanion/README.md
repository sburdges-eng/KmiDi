# Kelly MIDI Companion

**Emotion-to-music generation system.**

Kelly understands that music is emotional architecture. Give her a feeling, and she'll give you notes.

## Installation

```bash
pip install -e .
```

## Quick Start

### Python API

```python
from kellymidicompanion import Kelly, compose

# Full control
kelly = Kelly()
piece = kelly.compose(
    emotion="grief",
    key="F",
    length=4,
    include_melody=True,
    include_drums=False
)
piece.export("grief.mid")
print(piece.summary())

# Quick functions
piece = compose("hope", "C", include_drums=True)
piece.export("hope.mid")
```

### Command Line

```bash
# Compose a piece
kelly compose --emotion grief --key F --output grief.mid

# With options
kelly compose -e rage -k E -t 140 --drums --verbose -o rage.mid

# List emotions
kelly list-emotions

# Generate demos
kelly demo

# Info
kelly info
```

## Supported Emotions

| Emotion | Character |
|---------|-----------|
| grief | Low, close voicings, slow, unresolved |
| hope | Open voicings, ascending, major |
| rage | Dense, angular, fast, dissonant |
| fear | Sparse, chromatic, unsettling |
| joy | Bright, open, energetic |
| longing | Suspended, unresolved, yearning |
| anxiety | Restless, syncopated, tense |
| tenderness | Soft, close, gentle |
| defiance | Strong, parallel motion, bold |
| melancholy | Minor, descending, bittersweet |
| nostalgia | Warm, familiar progressions |
| euphoria | High, spread, ecstatic |
| dissociation | Sparse, disconnected, floating |
| neutral | Balanced, standard voicings |

## Components

### Voice Leading Engine

Ensures smooth voice connections between chords with emotion-aware voicing styles.

```python
from kellymidicompanion import VoiceLeadingEngine

engine = VoiceLeadingEngine()
output = engine.voice_progression(
    chords=["F", "C", "Dm", "Bbm"],
    key="F",
    emotion="grief",
    num_voices=4
)
```

### Progression Engine

Generates chord progressions based on emotional character.

```python
from kellymidicompanion import ProgressionEngine

engine = ProgressionEngine()
progression = engine.generate(key="C", emotion="hope", length=4)
print(progression.chords)  # ['C', 'G', 'Am', 'F']
```

### Melody Engine

Creates melodies with emotion-appropriate contours and note selection.

```python
from kellymidicompanion import MelodyEngine

engine = MelodyEngine()
melody = engine.generate(
    chords=["C", "G", "Am", "F"],
    key="C",
    emotion="joy",
    beats_per_chord=4.0
)
```

### Rhythm Engine

Generates rhythmic patterns and drum beats.

```python
from kellymidicompanion import RhythmEngine

engine = RhythmEngine()
drums = engine.generate_drum_pattern(emotion="rage", num_bars=4)
```

### MIDI Export

Exports to standard MIDI files.

```python
from kellymidicompanion import MidiExporter

exporter = MidiExporter()
exporter.export_full_composition(
    voiced_chords=voicing.voiced_chords,
    melody_output=melody,
    drum_pattern=drums,
    tempo=120,
    filename="composition.mid"
)
```

## Composition Object

The `Composition` class bundles all generated components:

```python
composition = kelly.compose(emotion="grief", key="F")

# Access components
composition.progression.chords      # Chord symbols
composition.voicing.voiced_chords   # Voiced chords with pitches
composition.melody                  # Melody notes
composition.drums                   # Drum pattern
composition.tempo                   # BPM
composition.key                     # Musical key

# Export
composition.export("output.mid")           # Full composition
composition.export_chords_only("chords.mid")
composition.export_melody_only("melody.mid")

# Info
print(composition.summary())
```

## Voicing Styles

- **close** - All voices within an octave
- **open** - Spread across multiple octaves
- **drop_2** - Second voice dropped an octave
- **spread** - Maximum spread
- **cluster** - Tight voicing with 2nds
- **rootless** - Jazz style without root

## Voice Leading Rules

Kelly can follow or break classical voice leading rules:

- Smooth motion (minimal movement)
- No parallel fifths/octaves
- Resolve tendency tones
- Keep common tones
- Contrary motion in outer voices

Different emotions break different rules for expressive effect.

## Examples

### Grief Piece

```python
kelly = Kelly()
piece = kelly.compose(
    emotion="grief",
    key="F",
    length=8,
    tempo=60,
    num_voices=4
)
piece.export("grief_piece.mid")
```

### Rage with Drums

```python
piece = kelly.compose(
    emotion="rage",
    key="E",
    length=4,
    include_drums=True,
    include_bass=True
)
piece.export("rage_with_drums.mid")
```

### Reproducible Composition

```python
piece = kelly.compose(
    emotion="hope",
    key="C",
    seed=42  # Same seed = same output
)
```

## Philosophy

Music is not just notes - it's emotion made audible. Kelly doesn't just generate random progressions; she understands that:

- **Grief** needs close voicings that feel heavy, unresolved suspensions
- **Hope** opens up, reaches upward, resolves clearly
- **Rage** breaks rules, moves angularly, builds intensity
- **Fear** leaves space, creates uncertainty, avoids resolution

Each emotion profile adjusts:
- Chord progression patterns
- Voice leading rules
- Voicing style and register
- Melodic contour and range
- Rhythmic density and feel

## License

MIT
