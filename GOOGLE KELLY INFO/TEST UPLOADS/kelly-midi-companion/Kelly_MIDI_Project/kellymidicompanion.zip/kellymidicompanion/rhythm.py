"""
Rhythm Engine - Generates emotionally-aware rhythmic patterns.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from enum import Enum
import random


class TimeSignature(Enum):
    FOUR_FOUR = (4, 4)
    THREE_FOUR = (3, 4)
    SIX_EIGHT = (6, 8)
    FIVE_FOUR = (5, 4)
    SEVEN_EIGHT = (7, 8)
    TWO_FOUR = (2, 4)


class RhythmFeel(Enum):
    STRAIGHT = "straight"
    SWING = "swing"
    SHUFFLE = "shuffle"
    PUSH = "push"
    LAID_BACK = "laid_back"


EMOTION_RHYTHM_PROFILES = {
    "grief": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.THREE_FOUR],
        "feel": RhythmFeel.LAID_BACK,
        "tempo_range": (50, 70),
        "subdivision": "half",  # half notes, quarter notes
        "syncopation": 0.1,
        "accent_pattern": [1.0, 0.3, 0.5, 0.3],
        "rest_density": 0.3,
        "rubato": 0.3,
    },
    "hope": {
        "time_signatures": [TimeSignature.FOUR_FOUR],
        "feel": RhythmFeel.STRAIGHT,
        "tempo_range": (80, 110),
        "subdivision": "quarter",
        "syncopation": 0.2,
        "accent_pattern": [1.0, 0.4, 0.7, 0.4],
        "rest_density": 0.15,
        "rubato": 0.1,
    },
    "rage": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.SEVEN_EIGHT],
        "feel": RhythmFeel.PUSH,
        "tempo_range": (120, 180),
        "subdivision": "eighth",
        "syncopation": 0.5,
        "accent_pattern": [1.0, 0.8, 0.9, 0.8],
        "rest_density": 0.05,
        "rubato": 0.0,
    },
    "fear": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.FIVE_FOUR],
        "feel": RhythmFeel.STRAIGHT,
        "tempo_range": (60, 90),
        "subdivision": "quarter",
        "syncopation": 0.3,
        "accent_pattern": [1.0, 0.2, 0.3, 0.2],
        "rest_density": 0.4,
        "rubato": 0.2,
    },
    "joy": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.TWO_FOUR],
        "feel": RhythmFeel.SWING,
        "tempo_range": (110, 140),
        "subdivision": "eighth",
        "syncopation": 0.3,
        "accent_pattern": [1.0, 0.5, 0.8, 0.5],
        "rest_density": 0.1,
        "rubato": 0.05,
    },
    "longing": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.SIX_EIGHT],
        "feel": RhythmFeel.LAID_BACK,
        "tempo_range": (65, 85),
        "subdivision": "quarter",
        "syncopation": 0.15,
        "accent_pattern": [1.0, 0.3, 0.6, 0.3],
        "rest_density": 0.25,
        "rubato": 0.25,
    },
    "anxiety": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.SEVEN_EIGHT],
        "feel": RhythmFeel.PUSH,
        "tempo_range": (90, 130),
        "subdivision": "sixteenth",
        "syncopation": 0.4,
        "accent_pattern": [1.0, 0.6, 0.7, 0.6],
        "rest_density": 0.1,
        "rubato": 0.0,
    },
    "tenderness": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.THREE_FOUR],
        "feel": RhythmFeel.LAID_BACK,
        "tempo_range": (55, 75),
        "subdivision": "quarter",
        "syncopation": 0.05,
        "accent_pattern": [1.0, 0.2, 0.4, 0.2],
        "rest_density": 0.2,
        "rubato": 0.2,
    },
    "defiance": {
        "time_signatures": [TimeSignature.FOUR_FOUR],
        "feel": RhythmFeel.PUSH,
        "tempo_range": (100, 130),
        "subdivision": "eighth",
        "syncopation": 0.35,
        "accent_pattern": [1.0, 0.7, 0.9, 0.7],
        "rest_density": 0.1,
        "rubato": 0.0,
    },
    "melancholy": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.THREE_FOUR],
        "feel": RhythmFeel.LAID_BACK,
        "tempo_range": (55, 75),
        "subdivision": "quarter",
        "syncopation": 0.1,
        "accent_pattern": [1.0, 0.25, 0.45, 0.25],
        "rest_density": 0.3,
        "rubato": 0.25,
    },
    "nostalgia": {
        "time_signatures": [TimeSignature.FOUR_FOUR, TimeSignature.SIX_EIGHT],
        "feel": RhythmFeel.SHUFFLE,
        "tempo_range": (70, 95),
        "subdivision": "quarter",
        "syncopation": 0.15,
        "accent_pattern": [1.0, 0.35, 0.6, 0.35],
        "rest_density": 0.2,
        "rubato": 0.15,
    },
    "euphoria": {
        "time_signatures": [TimeSignature.FOUR_FOUR],
        "feel": RhythmFeel.PUSH,
        "tempo_range": (120, 150),
        "subdivision": "eighth",
        "syncopation": 0.4,
        "accent_pattern": [1.0, 0.7, 0.9, 0.7],
        "rest_density": 0.05,
        "rubato": 0.0,
    },
    "dissociation": {
        "time_signatures": [TimeSignature.FIVE_FOUR, TimeSignature.SEVEN_EIGHT],
        "feel": RhythmFeel.STRAIGHT,
        "tempo_range": (50, 80),
        "subdivision": "quarter",
        "syncopation": 0.2,
        "accent_pattern": [1.0, 0.3, 0.3, 0.3],
        "rest_density": 0.4,
        "rubato": 0.3,
    },
    "neutral": {
        "time_signatures": [TimeSignature.FOUR_FOUR],
        "feel": RhythmFeel.STRAIGHT,
        "tempo_range": (90, 120),
        "subdivision": "quarter",
        "syncopation": 0.15,
        "accent_pattern": [1.0, 0.4, 0.6, 0.4],
        "rest_density": 0.15,
        "rubato": 0.1,
    },
}


@dataclass
class RhythmEvent:
    start_beat: float
    duration: float
    velocity: int
    is_accent: bool
    is_rest: bool


@dataclass
class RhythmPattern:
    events: List[RhythmEvent]
    time_signature: TimeSignature
    feel: RhythmFeel
    tempo: int
    total_beats: float

    def get_hit_times(self) -> List[float]:
        """Get beat positions of all non-rest events."""
        return [e.start_beat for e in self.events if not e.is_rest]

    def to_ticks(self, ticks_per_beat: int = 480) -> List[Tuple[int, int, int]]:
        """Convert to (tick, duration_ticks, velocity) tuples."""
        result = []
        for e in self.events:
            if not e.is_rest:
                tick = int(e.start_beat * ticks_per_beat)
                dur = int(e.duration * ticks_per_beat)
                result.append((tick, dur, e.velocity))
        return result


@dataclass
class DrumPattern:
    kick: RhythmPattern
    snare: RhythmPattern
    hihat: RhythmPattern
    time_signature: TimeSignature
    tempo: int


class RhythmEngine:
    """Generates emotion-aware rhythmic patterns."""

    def __init__(self, custom_profiles: Optional[Dict] = None):
        self.profiles = EMOTION_RHYTHM_PROFILES.copy()
        if custom_profiles:
            self.profiles.update(custom_profiles)

    def generate(self, emotion: str = "neutral", num_bars: int = 4,
                 seed: Optional[int] = None) -> RhythmPattern:
        """Generate a rhythm pattern."""
        if seed is not None:
            random.seed(seed)

        emotion = emotion.lower()
        profile = self.profiles.get(emotion, self.profiles["neutral"])

        time_sig = random.choice(profile["time_signatures"])
        beats_per_bar = time_sig.value[0]
        total_beats = beats_per_bar * num_bars

        tempo = random.randint(*profile["tempo_range"])
        feel = profile["feel"]

        events = self._generate_events(total_beats, profile, time_sig)

        return RhythmPattern(
            events=events,
            time_signature=time_sig,
            feel=feel,
            tempo=tempo,
            total_beats=total_beats
        )

    def _generate_events(self, total_beats: float, profile: Dict,
                         time_sig: TimeSignature) -> List[RhythmEvent]:
        """Generate rhythm events for pattern."""
        events = []
        beat = 0.0

        # Subdivision determines smallest unit
        subdivision_map = {
            "whole": 4.0,
            "half": 2.0,
            "quarter": 1.0,
            "eighth": 0.5,
            "sixteenth": 0.25,
        }
        unit = subdivision_map.get(profile["subdivision"], 1.0)

        accent_pattern = profile["accent_pattern"]
        beats_per_bar = time_sig.value[0]

        while beat < total_beats:
            # Check if rest
            if random.random() < profile["rest_density"]:
                duration = unit * random.choice([1, 2])
                events.append(RhythmEvent(
                    start_beat=beat, duration=duration, velocity=0,
                    is_accent=False, is_rest=True
                ))
                beat += duration
                continue

            # Duration (with some variation)
            possible_durations = [unit, unit * 2]
            if unit <= 0.5:
                possible_durations.append(unit * 0.5)
            duration = random.choice(possible_durations)

            # Syncopation (offset from beat)
            offset = 0.0
            if random.random() < profile["syncopation"]:
                offset = unit * 0.5

            # Velocity based on position in bar
            bar_position = int(beat % beats_per_bar)
            accent_idx = bar_position % len(accent_pattern)
            base_velocity = int(60 + 40 * accent_pattern[accent_idx])

            # Add variation
            velocity = max(40, min(127, base_velocity + random.randint(-10, 10)))

            is_accent = accent_pattern[accent_idx] > 0.7

            events.append(RhythmEvent(
                start_beat=beat + offset,
                duration=duration,
                velocity=velocity,
                is_accent=is_accent,
                is_rest=False
            ))

            beat += duration

        return events

    def generate_drum_pattern(self, emotion: str = "neutral", num_bars: int = 4,
                              seed: Optional[int] = None) -> DrumPattern:
        """Generate a basic drum pattern."""
        if seed is not None:
            random.seed(seed)

        emotion = emotion.lower()
        profile = self.profiles.get(emotion, self.profiles["neutral"])

        time_sig = random.choice(profile["time_signatures"])
        beats_per_bar = time_sig.value[0]
        total_beats = beats_per_bar * num_bars
        tempo = random.randint(*profile["tempo_range"])

        # Generate each part
        kick_events = self._generate_kick(total_beats, beats_per_bar, profile)
        snare_events = self._generate_snare(total_beats, beats_per_bar, profile)
        hihat_events = self._generate_hihat(total_beats, profile)

        return DrumPattern(
            kick=RhythmPattern(kick_events, time_sig, profile["feel"], tempo, total_beats),
            snare=RhythmPattern(snare_events, time_sig, profile["feel"], tempo, total_beats),
            hihat=RhythmPattern(hihat_events, time_sig, profile["feel"], tempo, total_beats),
            time_signature=time_sig,
            tempo=tempo
        )

    def _generate_kick(self, total_beats: float, beats_per_bar: int,
                       profile: Dict) -> List[RhythmEvent]:
        """Generate kick pattern."""
        events = []
        beat = 0.0

        while beat < total_beats:
            bar_pos = beat % beats_per_bar

            # Kick typically on 1 and 3 (in 4/4)
            should_hit = False
            if bar_pos == 0:
                should_hit = True
            elif bar_pos == 2 and beats_per_bar == 4:
                should_hit = random.random() > 0.3

            # Syncopation
            if random.random() < profile["syncopation"] * 0.5:
                should_hit = not should_hit

            if should_hit:
                velocity = 100 if bar_pos == 0 else 85
                events.append(RhythmEvent(
                    start_beat=beat, duration=0.5, velocity=velocity,
                    is_accent=bar_pos == 0, is_rest=False
                ))

            beat += 1.0

        return events

    def _generate_snare(self, total_beats: float, beats_per_bar: int,
                        profile: Dict) -> List[RhythmEvent]:
        """Generate snare pattern."""
        events = []
        beat = 0.0

        while beat < total_beats:
            bar_pos = beat % beats_per_bar

            # Snare typically on 2 and 4
            should_hit = False
            if beats_per_bar == 4 and bar_pos in [1, 3]:
                should_hit = True
            elif beats_per_bar == 3 and bar_pos == 1:
                should_hit = True

            if should_hit:
                velocity = 95
                events.append(RhythmEvent(
                    start_beat=beat, duration=0.5, velocity=velocity,
                    is_accent=True, is_rest=False
                ))

            beat += 1.0

        return events

    def _generate_hihat(self, total_beats: float, profile: Dict) -> List[RhythmEvent]:
        """Generate hi-hat pattern."""
        events = []

        subdivision_map = {
            "whole": 2.0,
            "half": 1.0,
            "quarter": 0.5,
            "eighth": 0.25,
            "sixteenth": 0.125,
        }
        unit = subdivision_map.get(profile["subdivision"], 0.5)

        beat = 0.0
        while beat < total_beats:
            if random.random() > profile["rest_density"]:
                velocity = 70 + random.randint(-10, 10)
                events.append(RhythmEvent(
                    start_beat=beat, duration=unit, velocity=velocity,
                    is_accent=False, is_rest=False
                ))
            beat += unit

        return events

    def apply_swing(self, pattern: RhythmPattern, swing_amount: float = 0.33) -> RhythmPattern:
        """Apply swing feel to pattern."""
        swung_events = []

        for event in pattern.events:
            new_start = event.start_beat

            # Swing the off-beats
            fractional = event.start_beat % 1.0
            if 0.4 < fractional < 0.6:  # Close to half beat
                new_start = event.start_beat - fractional + 0.5 + (swing_amount * 0.5)

            swung_events.append(RhythmEvent(
                start_beat=new_start,
                duration=event.duration,
                velocity=event.velocity,
                is_accent=event.is_accent,
                is_rest=event.is_rest
            ))

        return RhythmPattern(
            events=swung_events,
            time_signature=pattern.time_signature,
            feel=RhythmFeel.SWING,
            tempo=pattern.tempo,
            total_beats=pattern.total_beats
        )


def generate_rhythm(emotion: str, num_bars: int = 4) -> RhythmPattern:
    """Quick rhythm generation."""
    return RhythmEngine().generate(emotion, num_bars)


def generate_drums(emotion: str, num_bars: int = 4) -> DrumPattern:
    """Quick drum pattern generation."""
    return RhythmEngine().generate_drum_pattern(emotion, num_bars)
