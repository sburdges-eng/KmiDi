"""
Melody Engine - Generates emotionally-aware melodies over chord progressions.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from enum import Enum
import random

from .voice_leading import CHROMATIC, note_name_to_midi, midi_to_note_name, parse_chord, CHORD_INTERVALS


SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11],
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "dorian": [0, 2, 3, 5, 7, 9, 10],
    "phrygian": [0, 1, 3, 5, 7, 8, 10],
    "lydian": [0, 2, 4, 6, 7, 9, 11],
    "mixolydian": [0, 2, 4, 5, 7, 9, 10],
    "pentatonic_major": [0, 2, 4, 7, 9],
    "pentatonic_minor": [0, 3, 5, 7, 10],
    "blues": [0, 3, 5, 6, 7, 10],
}


class MelodicContour(Enum):
    ASCENDING = "ascending"
    DESCENDING = "descending"
    ARCH = "arch"
    INVERTED_ARCH = "inverted_arch"
    STATIC = "static"
    WAVE = "wave"


class RhythmicDensity(Enum):
    SPARSE = "sparse"
    MODERATE = "moderate"
    DENSE = "dense"


EMOTION_MELODY_PROFILES = {
    "grief": {
        "scale": "minor",
        "contours": [MelodicContour.DESCENDING, MelodicContour.ARCH],
        "range_octaves": 1.0,
        "leap_probability": 0.15,
        "max_leap": 5,
        "chord_tone_weight": 0.7,
        "passing_tone_weight": 0.2,
        "register": "low",
        "density": RhythmicDensity.SPARSE,
        "rest_probability": 0.3,
        "syncopation": 0.1,
    },
    "hope": {
        "scale": "major",
        "contours": [MelodicContour.ASCENDING, MelodicContour.ARCH],
        "range_octaves": 1.5,
        "leap_probability": 0.3,
        "max_leap": 7,
        "chord_tone_weight": 0.6,
        "passing_tone_weight": 0.3,
        "register": "mid",
        "density": RhythmicDensity.MODERATE,
        "rest_probability": 0.15,
        "syncopation": 0.2,
    },
    "rage": {
        "scale": "minor",
        "contours": [MelodicContour.WAVE, MelodicContour.ASCENDING],
        "range_octaves": 2.0,
        "leap_probability": 0.5,
        "max_leap": 12,
        "chord_tone_weight": 0.5,
        "passing_tone_weight": 0.3,
        "register": "mid",
        "density": RhythmicDensity.DENSE,
        "rest_probability": 0.05,
        "syncopation": 0.5,
    },
    "fear": {
        "scale": "phrygian",
        "contours": [MelodicContour.STATIC, MelodicContour.DESCENDING],
        "range_octaves": 0.8,
        "leap_probability": 0.4,
        "max_leap": 6,
        "chord_tone_weight": 0.5,
        "passing_tone_weight": 0.4,
        "register": "low",
        "density": RhythmicDensity.SPARSE,
        "rest_probability": 0.4,
        "syncopation": 0.3,
    },
    "joy": {
        "scale": "major",
        "contours": [MelodicContour.ARCH, MelodicContour.ASCENDING],
        "range_octaves": 1.5,
        "leap_probability": 0.35,
        "max_leap": 8,
        "chord_tone_weight": 0.7,
        "passing_tone_weight": 0.2,
        "register": "high",
        "density": RhythmicDensity.MODERATE,
        "rest_probability": 0.1,
        "syncopation": 0.3,
    },
    "longing": {
        "scale": "dorian",
        "contours": [MelodicContour.ARCH, MelodicContour.WAVE],
        "range_octaves": 1.2,
        "leap_probability": 0.25,
        "max_leap": 7,
        "chord_tone_weight": 0.6,
        "passing_tone_weight": 0.3,
        "register": "mid",
        "density": RhythmicDensity.SPARSE,
        "rest_probability": 0.25,
        "syncopation": 0.15,
    },
    "anxiety": {
        "scale": "minor",
        "contours": [MelodicContour.WAVE, MelodicContour.STATIC],
        "range_octaves": 1.0,
        "leap_probability": 0.35,
        "max_leap": 5,
        "chord_tone_weight": 0.5,
        "passing_tone_weight": 0.4,
        "register": "mid",
        "density": RhythmicDensity.DENSE,
        "rest_probability": 0.1,
        "syncopation": 0.4,
    },
    "tenderness": {
        "scale": "major",
        "contours": [MelodicContour.ARCH, MelodicContour.DESCENDING],
        "range_octaves": 1.0,
        "leap_probability": 0.15,
        "max_leap": 4,
        "chord_tone_weight": 0.8,
        "passing_tone_weight": 0.15,
        "register": "mid",
        "density": RhythmicDensity.SPARSE,
        "rest_probability": 0.2,
        "syncopation": 0.05,
    },
    "defiance": {
        "scale": "mixolydian",
        "contours": [MelodicContour.ASCENDING, MelodicContour.WAVE],
        "range_octaves": 1.5,
        "leap_probability": 0.4,
        "max_leap": 8,
        "chord_tone_weight": 0.6,
        "passing_tone_weight": 0.3,
        "register": "mid",
        "density": RhythmicDensity.MODERATE,
        "rest_probability": 0.1,
        "syncopation": 0.35,
    },
    "melancholy": {
        "scale": "minor",
        "contours": [MelodicContour.DESCENDING, MelodicContour.INVERTED_ARCH],
        "range_octaves": 1.0,
        "leap_probability": 0.2,
        "max_leap": 5,
        "chord_tone_weight": 0.65,
        "passing_tone_weight": 0.25,
        "register": "low",
        "density": RhythmicDensity.SPARSE,
        "rest_probability": 0.3,
        "syncopation": 0.1,
    },
    "nostalgia": {
        "scale": "major",
        "contours": [MelodicContour.ARCH, MelodicContour.WAVE],
        "range_octaves": 1.2,
        "leap_probability": 0.25,
        "max_leap": 6,
        "chord_tone_weight": 0.7,
        "passing_tone_weight": 0.2,
        "register": "mid",
        "density": RhythmicDensity.MODERATE,
        "rest_probability": 0.2,
        "syncopation": 0.15,
    },
    "euphoria": {
        "scale": "major",
        "contours": [MelodicContour.ASCENDING, MelodicContour.ARCH],
        "range_octaves": 2.0,
        "leap_probability": 0.4,
        "max_leap": 10,
        "chord_tone_weight": 0.65,
        "passing_tone_weight": 0.25,
        "register": "high",
        "density": RhythmicDensity.DENSE,
        "rest_probability": 0.05,
        "syncopation": 0.4,
    },
    "dissociation": {
        "scale": "dorian",
        "contours": [MelodicContour.STATIC, MelodicContour.INVERTED_ARCH],
        "range_octaves": 1.5,
        "leap_probability": 0.5,
        "max_leap": 11,
        "chord_tone_weight": 0.4,
        "passing_tone_weight": 0.4,
        "register": "varied",
        "density": RhythmicDensity.SPARSE,
        "rest_probability": 0.4,
        "syncopation": 0.2,
    },
    "neutral": {
        "scale": "major",
        "contours": [MelodicContour.ARCH, MelodicContour.WAVE],
        "range_octaves": 1.0,
        "leap_probability": 0.25,
        "max_leap": 5,
        "chord_tone_weight": 0.7,
        "passing_tone_weight": 0.2,
        "register": "mid",
        "density": RhythmicDensity.MODERATE,
        "rest_probability": 0.15,
        "syncopation": 0.15,
    },
}


@dataclass
class MelodyNote:
    pitch: int  # MIDI
    duration: float  # In beats
    velocity: int
    is_rest: bool
    is_chord_tone: bool
    beat_position: float


@dataclass
class MelodyOutput:
    notes: List[MelodyNote]
    key: str
    scale: str
    emotion: str
    contour: MelodicContour
    total_duration: float

    def to_midi_events(self) -> List[Tuple[int, float, float, int]]:
        """Return (pitch, start_time, duration, velocity) tuples."""
        events = []
        time = 0.0
        for note in self.notes:
            if not note.is_rest:
                events.append((note.pitch, time, note.duration, note.velocity))
            time += note.duration
        return events

    def get_pitches(self) -> List[int]:
        """Get non-rest pitches."""
        return [n.pitch for n in self.notes if not n.is_rest]


def get_scale_pitches(key: str, scale_name: str, octave: int = 4) -> List[int]:
    """Get all pitches in a scale for an octave."""
    key_midi = note_name_to_midi(key, octave)
    intervals = SCALES.get(scale_name, SCALES["major"])
    return [key_midi + i for i in intervals]


def get_chord_tones(chord: str, octave: int = 4) -> List[int]:
    """Get chord tones for a chord symbol."""
    root, quality = parse_chord(chord)
    root_midi = note_name_to_midi(root, octave)
    intervals = CHORD_INTERVALS.get(quality, [0, 4, 7])
    return [root_midi + i for i in intervals]


class MelodyEngine:
    """Generates emotion-aware melodies."""

    def __init__(self, custom_profiles: Optional[Dict] = None):
        self.profiles = EMOTION_MELODY_PROFILES.copy()
        if custom_profiles:
            self.profiles.update(custom_profiles)

    def generate(self, chords: List[str], key: str = "C", emotion: str = "neutral",
                 beats_per_chord: float = 4.0, seed: Optional[int] = None) -> MelodyOutput:
        """Generate melody over chord progression."""
        if seed is not None:
            random.seed(seed)

        emotion = emotion.lower()
        profile = self.profiles.get(emotion, self.profiles["neutral"])

        contour = random.choice(profile["contours"])
        scale_name = profile["scale"]
        density = profile["density"]

        # Determine register center
        register_centers = {"low": 55, "mid": 67, "high": 79, "varied": 67}
        center = register_centers.get(profile["register"], 67)

        notes = []
        current_beat = 0.0
        prev_pitch = center

        for chord in chords:
            chord_tones = get_chord_tones(chord)
            scale_pitches = get_scale_pitches(key, scale_name)

            # Notes per chord based on density
            notes_count = {
                RhythmicDensity.SPARSE: random.randint(1, 3),
                RhythmicDensity.MODERATE: random.randint(3, 5),
                RhythmicDensity.DENSE: random.randint(5, 8),
            }[density]

            chord_notes = self._generate_chord_melody(
                chord_tones, scale_pitches, center, prev_pitch,
                notes_count, beats_per_chord, current_beat,
                contour, profile
            )

            notes.extend(chord_notes)
            current_beat += beats_per_chord

            if chord_notes:
                non_rests = [n for n in chord_notes if not n.is_rest]
                if non_rests:
                    prev_pitch = non_rests[-1].pitch

        return MelodyOutput(
            notes=notes,
            key=key,
            scale=scale_name,
            emotion=emotion,
            contour=contour,
            total_duration=current_beat
        )

    def _generate_chord_melody(self, chord_tones: List[int], scale_pitches: List[int],
                               center: int, prev_pitch: int, notes_count: int,
                               total_beats: float, start_beat: float,
                               contour: MelodicContour, profile: Dict) -> List[MelodyNote]:
        """Generate melody notes for one chord."""
        notes = []
        beat_pos = start_beat
        remaining_beats = total_beats

        for i in range(notes_count):
            if remaining_beats <= 0:
                break

            # Duration
            if i == notes_count - 1:
                duration = remaining_beats
            else:
                duration = min(random.choice([0.5, 1.0, 1.5, 2.0]), remaining_beats * 0.5)

            # Rest check
            if random.random() < profile["rest_probability"]:
                notes.append(MelodyNote(
                    pitch=0, duration=duration, velocity=0,
                    is_rest=True, is_chord_tone=False, beat_position=beat_pos
                ))
                beat_pos += duration
                remaining_beats -= duration
                continue

            # Pitch selection
            pitch = self._select_pitch(
                chord_tones, scale_pitches, center, prev_pitch,
                i, notes_count, contour, profile
            )

            # Velocity
            base_vel = 80
            if beat_pos % 1.0 < 0.1:  # On beat
                velocity = base_vel + random.randint(0, 15)
            else:
                velocity = base_vel - random.randint(0, 10)

            is_chord_tone = (pitch % 12) in [ct % 12 for ct in chord_tones]

            notes.append(MelodyNote(
                pitch=pitch, duration=duration, velocity=velocity,
                is_rest=False, is_chord_tone=is_chord_tone, beat_position=beat_pos
            ))

            prev_pitch = pitch
            beat_pos += duration
            remaining_beats -= duration

        return notes

    def _select_pitch(self, chord_tones: List[int], scale_pitches: List[int],
                      center: int, prev_pitch: int, note_idx: int, total_notes: int,
                      contour: MelodicContour, profile: Dict) -> int:
        """Select next melody pitch."""

        # Build candidate pool
        candidates = []

        # Chord tones (transposed to center octave)
        for ct in chord_tones:
            pitch = center + (ct % 12) - (center % 12)
            if pitch < center - 6:
                pitch += 12
            candidates.append((pitch, profile["chord_tone_weight"]))

        # Scale tones
        for sp in scale_pitches:
            pitch = center + (sp % 12) - (center % 12)
            if pitch < center - 6:
                pitch += 12
            candidates.append((pitch, profile["passing_tone_weight"]))

        # Apply contour bias
        progress = note_idx / max(1, total_notes - 1)

        if contour == MelodicContour.ASCENDING:
            bias = progress * 12 - 6
        elif contour == MelodicContour.DESCENDING:
            bias = -progress * 12 + 6
        elif contour == MelodicContour.ARCH:
            bias = 12 * (0.5 - abs(progress - 0.5)) - 3
        elif contour == MelodicContour.INVERTED_ARCH:
            bias = -12 * (0.5 - abs(progress - 0.5)) + 3
        elif contour == MelodicContour.WAVE:
            import math
            bias = 6 * math.sin(progress * 2 * math.pi)
        else:
            bias = 0

        # Weight candidates
        weighted = []
        for pitch, base_weight in candidates:
            # Distance penalty
            distance = abs(pitch - prev_pitch)
            if distance > profile["max_leap"]:
                weight = base_weight * 0.1
            else:
                weight = base_weight

            # Contour bonus
            if (bias > 0 and pitch > prev_pitch) or (bias < 0 and pitch < prev_pitch):
                weight *= 1.5

            weighted.append((pitch, weight))

        # Weighted selection
        total_weight = sum(w for _, w in weighted)
        if total_weight == 0:
            return prev_pitch

        r = random.random() * total_weight
        cumulative = 0
        for pitch, weight in weighted:
            cumulative += weight
            if r <= cumulative:
                return pitch

        return weighted[0][0]

    def generate_motif(self, key: str = "C", emotion: str = "neutral",
                       length: int = 4, seed: Optional[int] = None) -> List[MelodyNote]:
        """Generate a short melodic motif."""
        output = self.generate(["C"], key, emotion, beats_per_chord=length, seed=seed)
        return output.notes

    def develop_motif(self, motif: List[MelodyNote], technique: str = "sequence") -> List[MelodyNote]:
        """Develop a motif using classical techniques."""
        if technique == "sequence":
            # Transpose up a step
            return [MelodyNote(
                pitch=n.pitch + 2 if not n.is_rest else 0,
                duration=n.duration, velocity=n.velocity,
                is_rest=n.is_rest, is_chord_tone=n.is_chord_tone,
                beat_position=n.beat_position
            ) for n in motif]

        elif technique == "inversion":
            # Flip intervals
            if not motif or motif[0].is_rest:
                return motif
            first = motif[0].pitch
            return [MelodyNote(
                pitch=first - (n.pitch - first) if not n.is_rest else 0,
                duration=n.duration, velocity=n.velocity,
                is_rest=n.is_rest, is_chord_tone=n.is_chord_tone,
                beat_position=n.beat_position
            ) for n in motif]

        elif technique == "retrograde":
            return list(reversed(motif))

        elif technique == "augmentation":
            return [MelodyNote(
                pitch=n.pitch, duration=n.duration * 2, velocity=n.velocity,
                is_rest=n.is_rest, is_chord_tone=n.is_chord_tone,
                beat_position=n.beat_position * 2
            ) for n in motif]

        elif technique == "diminution":
            return [MelodyNote(
                pitch=n.pitch, duration=n.duration * 0.5, velocity=n.velocity,
                is_rest=n.is_rest, is_chord_tone=n.is_chord_tone,
                beat_position=n.beat_position * 0.5
            ) for n in motif]

        return motif


def generate_melody(chords: List[str], key: str, emotion: str, beats_per_chord: float = 4.0) -> MelodyOutput:
    """Quick melody generation."""
    return MelodyEngine().generate(chords, key, emotion, beats_per_chord)
