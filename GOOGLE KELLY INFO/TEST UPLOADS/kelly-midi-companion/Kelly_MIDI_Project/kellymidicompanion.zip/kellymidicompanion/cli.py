#!/usr/bin/env python3
"""
Kelly MIDI Companion - Command Line Interface

Usage:
    kelly compose --emotion grief --key F --output grief.mid
    kelly compose -e hope -k C -o hope.mid --tempo 100
    kelly list-emotions
    kelly demo
"""

import argparse
import sys
from pathlib import Path

from .kelly import Kelly, Composition


def cmd_compose(args):
    """Compose a piece."""
    kelly = Kelly(seed=args.seed)
    
    composition = kelly.compose(
        emotion=args.emotion,
        key=args.key,
        length=args.length,
        tempo=args.tempo,
        beats_per_chord=args.beats,
        num_voices=args.voices,
        include_melody=args.melody,
        include_drums=args.drums,
        include_bass=args.bass,
    )
    
    # Output
    output_path = args.output or f"{args.emotion}_{args.key}.mid"
    composition.export(output_path)
    
    if args.verbose:
        print(composition.summary())
        print()
    
    print(f"✓ Exported to: {output_path}")
    return 0


def cmd_list_emotions(args):
    """List supported emotions."""
    print("Supported emotions:")
    print()
    for emotion in Kelly.SUPPORTED_EMOTIONS:
        print(f"  • {emotion}")
    return 0


def cmd_demo(args):
    """Generate demo files for each emotion."""
    kelly = Kelly(seed=42)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True)
    
    print("Generating demo files...")
    print()
    
    for emotion in Kelly.SUPPORTED_EMOTIONS:
        composition = kelly.compose(
            emotion=emotion,
            key="C",
            length=4,
            include_melody=True
        )
        
        filename = output_dir / f"kelly_demo_{emotion}.mid"
        composition.export(str(filename))
        print(f"  ✓ {emotion}: {filename}")
    
    print()
    print(f"Generated {len(Kelly.SUPPORTED_EMOTIONS)} demo files in {output_dir}")
    return 0


def cmd_info(args):
    """Show info about Kelly."""
    print("""
╔═══════════════════════════════════════════════════════════╗
║             Kelly MIDI Companion v0.1.0                   ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  Kelly understands that music is emotional architecture.  ║
║  Give her a feeling, and she'll give you notes.           ║
║                                                           ║
║  Components:                                              ║
║    • Progression Engine - Emotion-aware chord sequences   ║
║    • Voice Leading Engine - Smooth voice connections      ║
║    • Melody Engine - Contour-based melody generation      ║
║    • Rhythm Engine - Feel and groove patterns             ║
║    • MIDI Export - Standard MIDI file output              ║
║                                                           ║
║  Supported Emotions:                                      ║
║    grief, hope, rage, fear, joy, longing, anxiety,        ║
║    tenderness, defiance, melancholy, nostalgia,           ║
║    euphoria, dissociation, neutral                        ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
    """)
    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="kelly",
        description="Kelly MIDI Companion - Emotion-to-music generation"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Compose command
    compose_parser = subparsers.add_parser("compose", help="Compose a piece")
    compose_parser.add_argument("-e", "--emotion", default="neutral",
                                help="Emotional character (default: neutral)")
    compose_parser.add_argument("-k", "--key", default="C",
                                help="Musical key (default: C)")
    compose_parser.add_argument("-l", "--length", type=int, default=4,
                                help="Number of chords (default: 4)")
    compose_parser.add_argument("-t", "--tempo", type=int, default=None,
                                help="Tempo in BPM (auto if not set)")
    compose_parser.add_argument("-b", "--beats", type=float, default=4.0,
                                help="Beats per chord (default: 4)")
    compose_parser.add_argument("-v", "--voices", type=int, default=4,
                                help="Number of voices (default: 4)")
    compose_parser.add_argument("-o", "--output", default=None,
                                help="Output MIDI file")
    compose_parser.add_argument("--melody", action="store_true", default=True,
                                help="Include melody (default: True)")
    compose_parser.add_argument("--no-melody", action="store_false", dest="melody",
                                help="Exclude melody")
    compose_parser.add_argument("--drums", action="store_true", default=False,
                                help="Include drums")
    compose_parser.add_argument("--bass", action="store_true", default=False,
                                help="Include bass line")
    compose_parser.add_argument("--seed", type=int, default=None,
                                help="Random seed for reproducibility")
    compose_parser.add_argument("--verbose", action="store_true",
                                help="Show composition details")
    compose_parser.set_defaults(func=cmd_compose)
    
    # List emotions command
    list_parser = subparsers.add_parser("list-emotions", help="List supported emotions")
    list_parser.set_defaults(func=cmd_list_emotions)
    
    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Generate demo files")
    demo_parser.add_argument("-o", "--output-dir", default="kelly_demos",
                            help="Output directory (default: kelly_demos)")
    demo_parser.set_defaults(func=cmd_demo)
    
    # Info command
    info_parser = subparsers.add_parser("info", help="Show info about Kelly")
    info_parser.set_defaults(func=cmd_info)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return 0
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
