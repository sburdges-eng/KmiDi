"""
Chord Progression Engine - Generates emotionally-aware chord progressions.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from enum import Enum
import random


CHROMATIC = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]
MINOR_SCALE = [0, 2, 3, 5, 7, 8, 10]
DORIAN_SCALE = [0, 2, 3, 5, 7, 9, 10]
PHRYGIAN_SCALE = [0, 1, 3, 5, 7, 8, 10]
LYDIAN_SCALE = [0, 2, 4, 6, 7, 9, 11]
MIXOLYDIAN_SCALE = [0, 2, 4, 5, 7, 9, 10]
LOCRIAN_SCALE = [0, 1, 3, 5, 6, 8, 10]

SCALES = {
    "major": MAJOR_SCALE,
    "minor": MINOR_SCALE,
    "dorian": DORIAN_SCALE,
    "phrygian": PHRYGIAN_SCALE,
    "lydian": LYDIAN_SCALE,
    "mixolydian": MIXOLYDIAN_SCALE,
    "locrian": LOCRIAN_SCALE,
}

MAJOR_CHORD_QUALITIES = ["maj", "min", "min", "maj", "maj", "min", "dim"]
MINOR_CHORD_QUALITIES = ["min", "dim", "maj", "min", "min", "maj", "maj"]


class ProgressionType(Enum):
    DIATONIC = "diatonic"
    CHROMATIC = "chromatic"
    MODAL_INTERCHANGE = "modal_interchange"
    SECONDARY_DOMINANT = "secondary_dominant"
    TRITONE_SUB = "tritone_sub"


EMOTION_PROGRESSIONS = {
    "grief": {
        "patterns": [
            [1, 5, 6, 4],  # I V vi IV
            [6, 4, 1, 5],  # vi IV I V
            [1, 6, 4, 5],  # I vi IV V
            [4, 1, 5, 6],  # IV I V vi
        ],
        "mode": "minor",
        "borrowed_chords": ["bVI", "bVII", "iv"],
        "cadence_weight": 0.3,
        "chromaticism": 0.2,
        "tempo_suggestion": (50, 70),
    },
    "hope": {
        "patterns": [
            [1, 4, 5, 1],  # I IV V I
            [1, 5, 6, 4],  # I V vi IV
            [1, 4, 6, 5],  # I IV vi V
            [4, 5, 1, 1],  # IV V I
        ],
        "mode": "major",
        "borrowed_chords": ["IV", "V"],
        "cadence_weight": 0.8,
        "chromaticism": 0.1,
        "tempo_suggestion": (80, 110),
    },
    "rage": {
        "patterns": [
            [1, 7, 6, 5],  # i bVII bVI V (minor)
            [1, 1, 4, 5],  # Power chord feel
            [5, 4, 1, 1],
            [1, 3, 4, 5],
        ],
        "mode": "minor",
        "borrowed_chords": ["bII", "bVII", "#IV"],
        "cadence_weight": 0.2,
        "chromaticism": 0.5,
        "tempo_suggestion": (120, 180),
    },
    "fear": {
        "patterns": [
            [1, 2, 5, 1],  # Diminished movement
            [1, 4, 7, 1],
            [6, 7, 1, 5],
            [1, 5, 7, 4],
        ],
        "mode": "phrygian",
        "borrowed_chords": ["bII", "bVI", "dim"],
        "cadence_weight": 0.1,
        "chromaticism": 0.6,
        "tempo_suggestion": (60, 90),
    },
    "joy": {
        "patterns": [
            [1, 4, 5, 1],
            [1, 5, 4, 1],
            [1, 6, 4, 5],
            [4, 1, 5, 1],
        ],
        "mode": "major",
        "borrowed_chords": [],
        "cadence_weight": 0.9,
        "chromaticism": 0.0,
        "tempo_suggestion": (110, 140),
    },
    "longing": {
        "patterns": [
            [1, 3, 4, 5],  # Unresolved feel
            [2, 5, 1, 6],
            [6, 2, 5, 1],
            [1, 7, 6, 5],
        ],
        "mode": "major",
        "borrowed_chords": ["ii7", "IV7", "bVII"],
        "cadence_weight": 0.4,
        "chromaticism": 0.3,
        "tempo_suggestion": (65, 85),
    },
    "anxiety": {
        "patterns": [
            [1, 7, 4, 4],
            [5, 6, 4, 5],
            [2, 5, 2, 5],  # Restless
            [1, 4, 7, 3],
        ],
        "mode": "minor",
        "borrowed_chords": ["bVI", "bII"],
        "cadence_weight": 0.2,
        "chromaticism": 0.5,
        "tempo_suggestion": (90, 130),
    },
    "tenderness": {
        "patterns": [
            [1, 6, 4, 5],
            [1, 3, 4, 1],
            [2, 5, 1, 6],
            [4, 3, 2, 1],
        ],
        "mode": "major",
        "borrowed_chords": ["ii7", "IVmaj7"],
        "cadence_weight": 0.6,
        "chromaticism": 0.1,
        "tempo_suggestion": (55, 75),
    },
    "defiance": {
        "patterns": [
            [1, 5, 4, 4],
            [1, 7, 4, 1],
            [5, 4, 1, 5],
            [1, 1, 5, 4],
        ],
        "mode": "mixolydian",
        "borrowed_chords": ["bVII", "IV"],
        "cadence_weight": 0.5,
        "chromaticism": 0.3,
        "tempo_suggestion": (100, 130),
    },
    "melancholy": {
        "patterns": [
            [1, 6, 3, 7],
            [6, 4, 1, 5],
            [1, 7, 6, 5],
            [2, 5, 1, 4],
        ],
        "mode": "minor",
        "borrowed_chords": ["bVI", "bVII", "iv"],
        "cadence_weight": 0.3,
        "chromaticism": 0.25,
        "tempo_suggestion": (55, 75),
    },
    "nostalgia": {
        "patterns": [
            [1, 5, 6, 4],
            [1, 4, 6, 5],
            [6, 4, 1, 5],
            [1, 6, 2, 5],
        ],
        "mode": "major",
        "borrowed_chords": ["iv", "bVII"],
        "cadence_weight": 0.5,
        "chromaticism": 0.15,
        "tempo_suggestion": (70, 95),
    },
    "euphoria": {
        "patterns": [
            [1, 5, 6, 4],
            [4, 1, 5, 5],
            [1, 4, 1, 5],
            [6, 4, 1, 5],
        ],
        "mode": "major",
        "borrowed_chords": [],
        "cadence_weight": 0.9,
        "chromaticism": 0.0,
        "tempo_suggestion": (120, 150),
    },
    "dissociation": {
        "patterns": [
            [1, 5, 7, 4],
            [6, 3, 7, 2],
            [1, 3, 5, 7],
            [4, 7, 2, 6],
        ],
        "mode": "dorian",
        "borrowed_chords": ["bII", "bVI", "#iv"],
        "cadence_weight": 0.1,
        "chromaticism": 0.7,
        "tempo_suggestion": (50, 80),
    },
    "neutral": {
        "patterns": [
            [1, 4, 5, 1],
            [1, 5, 6, 4],
            [1, 6, 4, 5],
            [2, 5, 1, 1],
        ],
        "mode": "major",
        "borrowed_chords": [],
        "cadence_weight": 0.7,
        "chromaticism": 0.1,
        "tempo_suggestion": (90, 120),
    },
}


@dataclass
class ChordInfo:
    symbol: str
    root: str
    quality: str
    degree: int
    function: str  # "tonic", "subdominant", "dominant"
    is_borrowed: bool


@dataclass
class ProgressionOutput:
    chords: List[str]
    chord_info: List[ChordInfo]
    key: str
    mode: str
    emotion: str
    pattern_used: List[int]
    tempo_suggestion: Tuple[int, int]


def get_scale_degree_root(key: str, degree: int, mode: str = "major") -> str:
    """Get the root note for a scale degree."""
    key_idx = CHROMATIC.index(key.upper().replace("B", "#").replace("b", "#")
                              if key.upper() not in CHROMATIC else key.upper())
    scale = SCALES.get(mode, MAJOR_SCALE)
    interval = scale[(degree - 1) % 7]
    root_idx = (key_idx + interval) % 12
    return CHROMATIC[root_idx]


def get_chord_quality(degree: int, mode: str = "major") -> str:
    """Get natural chord quality for degree in mode."""
    if mode in ["major", "lydian", "mixolydian"]:
        qualities = MAJOR_CHORD_QUALITIES
    else:
        qualities = MINOR_CHORD_QUALITIES
    return qualities[(degree - 1) % 7]


def degree_to_function(degree: int) -> str:
    """Map scale degree to harmonic function."""
    if degree in [1, 3, 6]:
        return "tonic"
    elif degree in [2, 4]:
        return "subdominant"
    else:
        return "dominant"


class ProgressionEngine:
    """Generates emotion-aware chord progressions."""

    def __init__(self, custom_emotions: Optional[Dict] = None):
        self.emotions = EMOTION_PROGRESSIONS.copy()
        if custom_emotions:
            self.emotions.update(custom_emotions)

    def generate(self, key: str = "C", emotion: str = "neutral", length: int = 4,
                 seed: Optional[int] = None) -> ProgressionOutput:
        """Generate a chord progression."""
        if seed is not None:
            random.seed(seed)

        emotion = emotion.lower()
        profile = self.emotions.get(emotion, self.emotions["neutral"])

        pattern = random.choice(profile["patterns"])
        if length != len(pattern):
            pattern = self._adjust_pattern_length(pattern, length)

        mode = profile["mode"]
        chords = []
        chord_info = []

        for degree in pattern:
            root = get_scale_degree_root(key, degree, mode)
            quality = get_chord_quality(degree, mode)

            # Maybe borrow chord
            is_borrowed = False
            if profile["borrowed_chords"] and random.random() < profile["chromaticism"]:
                borrowed = random.choice(profile["borrowed_chords"])
                if borrowed.startswith("b"):
                    # Flat borrowed
                    root_idx = CHROMATIC.index(root)
                    root = CHROMATIC[(root_idx - 1) % 12]
                    quality = "maj"
                    is_borrowed = True

            symbol = f"{root}{'' if quality == 'maj' else 'm' if quality == 'min' else quality}"
            chords.append(symbol)

            info = ChordInfo(
                symbol=symbol,
                root=root,
                quality=quality,
                degree=degree,
                function=degree_to_function(degree),
                is_borrowed=is_borrowed
            )
            chord_info.append(info)

        return ProgressionOutput(
            chords=chords,
            chord_info=chord_info,
            key=key,
            mode=mode,
            emotion=emotion,
            pattern_used=pattern,
            tempo_suggestion=profile["tempo_suggestion"]
        )

    def _adjust_pattern_length(self, pattern: List[int], length: int) -> List[int]:
        """Adjust pattern to desired length."""
        if length < len(pattern):
            return pattern[:length]
        result = pattern.copy()
        while len(result) < length:
            result.extend(pattern)
        return result[:length]

    def generate_transition(self, from_key: str, to_key: str, emotion: str = "neutral") -> List[str]:
        """Generate a transitional progression between keys."""
        # Simple pivot chord approach
        chords = []
        chords.append(f"{from_key}")  # Start in original key
        
        # Common chord (usually ii or IV)
        pivot_root = get_scale_degree_root(from_key, 4)
        chords.append(f"{pivot_root}")
        
        # Secondary dominant
        dom_root = get_scale_degree_root(to_key, 5)
        chords.append(f"{dom_root}7")
        
        # Resolve to new key
        chords.append(f"{to_key}")
        
        return chords

    def suggest_next_chord(self, current_chord: str, key: str, emotion: str = "neutral") -> List[str]:
        """Suggest possible next chords."""
        suggestions = []
        profile = self.emotions.get(emotion.lower(), self.emotions["neutral"])
        mode = profile["mode"]

        # Common movements
        movements = {
            1: [4, 5, 6],
            2: [5, 1],
            3: [4, 6],
            4: [5, 1, 2],
            5: [1, 6],
            6: [4, 2, 5],
            7: [1, 3],
        }

        # Find current degree
        for deg in range(1, 8):
            root = get_scale_degree_root(key, deg, mode)
            if root == current_chord[0]:
                for next_deg in movements.get(deg, [1]):
                    next_root = get_scale_degree_root(key, next_deg, mode)
                    quality = get_chord_quality(next_deg, mode)
                    symbol = f"{next_root}{'' if quality == 'maj' else 'm' if quality == 'min' else quality}"
                    suggestions.append(symbol)
                break

        return suggestions[:4]


# Convenience functions
def generate_grief_progression(key: str = "F", length: int = 4) -> List[str]:
    """Quick grief progression."""
    return ProgressionEngine().generate(key, "grief", length).chords


def generate_hope_progression(key: str = "C", length: int = 4) -> List[str]:
    """Quick hope progression."""
    return ProgressionEngine().generate(key, "hope", length).chords


def generate_progression(key: str, emotion: str, length: int = 4) -> List[str]:
    """Quick progression generation."""
    return ProgressionEngine().generate(key, emotion, length).chords
