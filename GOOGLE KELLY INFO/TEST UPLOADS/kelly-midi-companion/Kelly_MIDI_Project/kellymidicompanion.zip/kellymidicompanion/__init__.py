"""
Kelly MIDI Companion
====================

Emotion-to-music generation system.

Kelly understands that music is emotional architecture.
Give her a feeling, and she'll give you notes.

Quick Start:
    from kellymidicompanion import Kelly, compose

    # Full control
    kelly = Kelly()
    piece = kelly.compose(emotion="grief", key="F")
    piece.export("grief.mid")
    print(piece.summary())

    # Quick functions
    piece = compose("hope", "C", include_drums=True)
    piece.export("hope.mid")

Supported Emotions:
    grief, hope, rage, fear, joy, longing, anxiety,
    tenderness, defiance, melancholy, nostalgia,
    euphoria, dissociation, neutral

Components:
    - ProgressionEngine: Chord progression generation
    - VoiceLeadingEngine: Voice leading and chord voicing
    - MelodyEngine: Melody generation
    - RhythmEngine: Rhythm and drum patterns
    - MidiExporter: MIDI file export
"""

__version__ = "0.1.0"
__author__ = "Kelly"

from .kelly import Kelly, Composition, compose, grief, hope, rage

from .voice_leading import (
    VoiceLeadingEngine,
    VoiceLeadingOutput,
    VoicedChord,
    Voice,
    VoiceConfig,
    VoicingStyle,
    VoiceLeadingRule,
    note_name_to_midi,
    midi_to_note_name,
    parse_chord,
    get_chord_pitches,
    CHROMATIC,
    CHORD_INTERVALS,
    EMOTION_VOICE_PROFILES,
)

from .progression import (
    ProgressionEngine,
    ProgressionOutput,
    ChordInfo,
    ProgressionType,
    generate_progression,
    generate_grief_progression,
    generate_hope_progression,
    EMOTION_PROGRESSIONS,
)

from .melody import (
    MelodyEngine,
    MelodyOutput,
    MelodyNote,
    MelodicContour,
    RhythmicDensity,
    generate_melody,
    EMOTION_MELODY_PROFILES,
)

from .rhythm import (
    RhythmEngine,
    RhythmPattern,
    DrumPattern,
    RhythmEvent,
    TimeSignature,
    RhythmFeel,
    generate_rhythm,
    generate_drums,
    EMOTION_RHYTHM_PROFILES,
)

from .midi_export import (
    MidiExporter,
    MidiWriter,
    MidiTrack,
    MidiNote,
    export_to_midi,
    GM_DRUMS,
    GM_INSTRUMENTS,
    TICKS_PER_BEAT,
)


__all__ = [
    # Main
    "Kelly",
    "Composition",
    "compose",
    "grief",
    "hope",
    "rage",
    
    # Voice Leading
    "VoiceLeadingEngine",
    "VoiceLeadingOutput",
    "VoicedChord",
    "Voice",
    "VoiceConfig",
    "VoicingStyle",
    "VoiceLeadingRule",
    
    # Progression
    "ProgressionEngine",
    "ProgressionOutput",
    "ChordInfo",
    "ProgressionType",
    "generate_progression",
    
    # Melody
    "MelodyEngine",
    "MelodyOutput",
    "MelodyNote",
    "MelodicContour",
    "generate_melody",
    
    # Rhythm
    "RhythmEngine",
    "RhythmPattern",
    "DrumPattern",
    "RhythmEvent",
    "TimeSignature",
    "RhythmFeel",
    "generate_rhythm",
    "generate_drums",
    
    # MIDI
    "MidiExporter",
    "MidiWriter",
    "MidiTrack",
    "MidiNote",
    "export_to_midi",
    
    # Utilities
    "note_name_to_midi",
    "midi_to_note_name",
    "parse_chord",
    "get_chord_pitches",
    
    # Constants
    "CHROMATIC",
    "CHORD_INTERVALS",
    "GM_DRUMS",
    "GM_INSTRUMENTS",
    "TICKS_PER_BEAT",
    
    # Profiles
    "EMOTION_VOICE_PROFILES",
    "EMOTION_PROGRESSIONS",
    "EMOTION_MELODY_PROFILES",
    "EMOTION_RHYTHM_PROFILES",
]
