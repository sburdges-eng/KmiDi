"""
Voice Leading Engine - Ensures smooth voice connections between chords.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Set
from enum import Enum
import random


CHROMATIC = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
TICKS_PER_BEAT = 480

CHORD_INTERVALS = {
    "maj": [0, 4, 7],
    "min": [0, 3, 7],
    "dim": [0, 3, 6],
    "aug": [0, 4, 8],
    "7": [0, 4, 7, 10],
    "maj7": [0, 4, 7, 11],
    "min7": [0, 3, 7, 10],
    "dim7": [0, 3, 6, 9],
    "sus2": [0, 2, 7],
    "sus4": [0, 5, 7],
    "add9": [0, 4, 7, 14],
    "6": [0, 4, 7, 9],
    "min6": [0, 3, 7, 9],
    "9": [0, 4, 7, 10, 14],
    "min9": [0, 3, 7, 10, 14],
}

VOICE_RANGES = {
    "soprano": (60, 84),
    "alto": (53, 77),
    "tenor": (48, 72),
    "bass": (36, 60),
}


class VoicingStyle(Enum):
    CLOSE = "close"
    OPEN = "open"
    DROP_2 = "drop_2"
    DROP_3 = "drop_3"
    SPREAD = "spread"
    CLUSTER = "cluster"
    ROOTLESS = "rootless"


class VoiceLeadingRule(Enum):
    SMOOTH_MOTION = "smooth_motion"
    NO_PARALLEL_5THS = "no_parallel_5ths"
    NO_PARALLEL_8VAS = "no_parallel_8vas"
    RESOLVE_TENDENCY = "resolve_tendency"
    COMMON_TONES = "common_tones"
    CONTRARY_MOTION = "contrary_motion"


EMOTION_VOICE_PROFILES = {
    "grief": {
        "voicing_style": [VoicingStyle.CLOSE, VoicingStyle.DROP_2],
        "preferred_register": "low",
        "voice_count": 4,
        "rules_to_break": [VoiceLeadingRule.RESOLVE_TENDENCY],
        "dissonance_tolerance": 0.3,
        "spread_tendency": 0.3,
        "bass_movement": "stepwise",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.4,
        "anticipation_probability": 0.1,
    },
    "hope": {
        "voicing_style": [VoicingStyle.OPEN, VoicingStyle.SPREAD],
        "preferred_register": "mid",
        "voice_count": 4,
        "rules_to_break": [],
        "dissonance_tolerance": 0.1,
        "spread_tendency": 0.7,
        "bass_movement": "root_motion",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.2,
        "anticipation_probability": 0.3,
    },
    "rage": {
        "voicing_style": [VoicingStyle.CLUSTER, VoicingStyle.CLOSE],
        "preferred_register": "mid",
        "voice_count": 5,
        "rules_to_break": [VoiceLeadingRule.NO_PARALLEL_5THS, VoiceLeadingRule.SMOOTH_MOTION],
        "dissonance_tolerance": 0.7,
        "spread_tendency": 0.4,
        "bass_movement": "angular",
        "voice_crossing_allowed": True,
        "suspension_probability": 0.1,
        "anticipation_probability": 0.5,
    },
    "fear": {
        "voicing_style": [VoicingStyle.CLUSTER, VoicingStyle.DROP_3],
        "preferred_register": "low",
        "voice_count": 3,
        "rules_to_break": [VoiceLeadingRule.COMMON_TONES],
        "dissonance_tolerance": 0.6,
        "spread_tendency": 0.5,
        "bass_movement": "chromatic",
        "voice_crossing_allowed": True,
        "suspension_probability": 0.5,
        "anticipation_probability": 0.2,
    },
    "joy": {
        "voicing_style": [VoicingStyle.OPEN, VoicingStyle.SPREAD],
        "preferred_register": "high",
        "voice_count": 4,
        "rules_to_break": [],
        "dissonance_tolerance": 0.1,
        "spread_tendency": 0.8,
        "bass_movement": "root_motion",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.1,
        "anticipation_probability": 0.3,
    },
    "longing": {
        "voicing_style": [VoicingStyle.OPEN, VoicingStyle.DROP_2],
        "preferred_register": "mid",
        "voice_count": 4,
        "rules_to_break": [VoiceLeadingRule.RESOLVE_TENDENCY],
        "dissonance_tolerance": 0.4,
        "spread_tendency": 0.6,
        "bass_movement": "stepwise",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.5,
        "anticipation_probability": 0.2,
    },
    "anxiety": {
        "voicing_style": [VoicingStyle.CLUSTER, VoicingStyle.CLOSE],
        "preferred_register": "mid",
        "voice_count": 4,
        "rules_to_break": [VoiceLeadingRule.SMOOTH_MOTION, VoiceLeadingRule.COMMON_TONES],
        "dissonance_tolerance": 0.5,
        "spread_tendency": 0.3,
        "bass_movement": "angular",
        "voice_crossing_allowed": True,
        "suspension_probability": 0.3,
        "anticipation_probability": 0.4,
    },
    "tenderness": {
        "voicing_style": [VoicingStyle.CLOSE, VoicingStyle.DROP_2],
        "preferred_register": "mid",
        "voice_count": 3,
        "rules_to_break": [],
        "dissonance_tolerance": 0.1,
        "spread_tendency": 0.4,
        "bass_movement": "stepwise",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.3,
        "anticipation_probability": 0.1,
    },
    "defiance": {
        "voicing_style": [VoicingStyle.OPEN, VoicingStyle.SPREAD],
        "preferred_register": "mid",
        "voice_count": 4,
        "rules_to_break": [VoiceLeadingRule.NO_PARALLEL_5THS],
        "dissonance_tolerance": 0.4,
        "spread_tendency": 0.6,
        "bass_movement": "root_motion",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.2,
        "anticipation_probability": 0.4,
    },
    "melancholy": {
        "voicing_style": [VoicingStyle.DROP_2, VoicingStyle.CLOSE],
        "preferred_register": "low",
        "voice_count": 4,
        "rules_to_break": [VoiceLeadingRule.RESOLVE_TENDENCY],
        "dissonance_tolerance": 0.35,
        "spread_tendency": 0.4,
        "bass_movement": "chromatic",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.45,
        "anticipation_probability": 0.15,
    },
    "nostalgia": {
        "voicing_style": [VoicingStyle.CLOSE, VoicingStyle.OPEN],
        "preferred_register": "mid",
        "voice_count": 4,
        "rules_to_break": [],
        "dissonance_tolerance": 0.2,
        "spread_tendency": 0.5,
        "bass_movement": "root_motion",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.3,
        "anticipation_probability": 0.2,
    },
    "euphoria": {
        "voicing_style": [VoicingStyle.SPREAD, VoicingStyle.OPEN],
        "preferred_register": "high",
        "voice_count": 5,
        "rules_to_break": [],
        "dissonance_tolerance": 0.15,
        "spread_tendency": 0.9,
        "bass_movement": "root_motion",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.1,
        "anticipation_probability": 0.4,
    },
    "dissociation": {
        "voicing_style": [VoicingStyle.SPREAD, VoicingStyle.ROOTLESS],
        "preferred_register": "varied",
        "voice_count": 3,
        "rules_to_break": [VoiceLeadingRule.SMOOTH_MOTION, VoiceLeadingRule.COMMON_TONES],
        "dissonance_tolerance": 0.5,
        "spread_tendency": 0.7,
        "bass_movement": "angular",
        "voice_crossing_allowed": True,
        "suspension_probability": 0.4,
        "anticipation_probability": 0.1,
    },
    "neutral": {
        "voicing_style": [VoicingStyle.CLOSE, VoicingStyle.OPEN],
        "preferred_register": "mid",
        "voice_count": 4,
        "rules_to_break": [],
        "dissonance_tolerance": 0.2,
        "spread_tendency": 0.5,
        "bass_movement": "root_motion",
        "voice_crossing_allowed": False,
        "suspension_probability": 0.2,
        "anticipation_probability": 0.2,
    },
}


@dataclass
class Voice:
    pitch: int
    voice_name: str
    chord_function: str
    is_doubled: bool


@dataclass
class VoicedChord:
    symbol: str
    root: int
    quality: str
    voices: List[Voice]
    bass_note: int
    voicing_style: VoicingStyle
    has_suspension: bool
    has_anticipation: bool

    def get_pitches(self) -> List[int]:
        return sorted([v.pitch for v in self.voices])

    def get_pitch_classes(self) -> Set[int]:
        return {v.pitch % 12 for v in self.voices}


@dataclass
class VoiceConfig:
    emotion: str = "neutral"
    num_voices: int = 4
    key: str = "C"
    register: str = "mid"
    seed: Optional[int] = None
    voicing_override: Optional[VoicingStyle] = None
    allow_rule_breaking: bool = True


@dataclass
class VoiceLeadingOutput:
    voiced_chords: List[VoicedChord]
    config: VoiceConfig
    voicing_style_used: VoicingStyle
    rules_broken: List[VoiceLeadingRule]
    total_voice_movement: int
    smoothness_score: float

    def to_midi_data(self) -> List[List[Tuple[int, int]]]:
        result = []
        for vc in self.voiced_chords:
            chord_notes = [(v.pitch, 80) for v in vc.voices]
            result.append(chord_notes)
        return result

    def get_voice_motion(self, voice_idx: int) -> List[int]:
        return [vc.voices[voice_idx].pitch for vc in self.voiced_chords
                if voice_idx < len(vc.voices)]


def note_name_to_midi(note: str, octave: int = 4) -> int:
    note = note.upper().strip()
    flat_map = {"DB": "C#", "EB": "D#", "FB": "E", "GB": "F#", "AB": "G#", "BB": "A#", "CB": "B"}
    if len(note) >= 2 and note[1] in "#B":
        note_part = note[:2]
    else:
        note_part = note[0]
    if note_part.upper() in flat_map:
        note_part = flat_map[note_part.upper()]
    if note_part in CHROMATIC:
        return CHROMATIC.index(note_part) + (octave + 1) * 12
    return 60


def midi_to_note_name(midi: int) -> str:
    note_idx = midi % 12
    octave = (midi // 12) - 1
    return f"{CHROMATIC[note_idx]}{octave}"


def parse_chord(chord_str: str) -> Tuple[str, str]:
    chord_str = chord_str.strip()
    if len(chord_str) >= 2 and chord_str[1] in "#b":
        root = chord_str[:2]
        remainder = chord_str[2:]
    else:
        root = chord_str[0]
        remainder = chord_str[1:]

    remainder_lower = remainder.lower()
    if remainder_lower.startswith("maj7"):
        quality = "maj7"
    elif remainder_lower.startswith("min7") or remainder_lower.startswith("m7"):
        quality = "min7"
    elif remainder_lower.startswith("dim7"):
        quality = "dim7"
    elif remainder_lower.startswith("dim") or remainder_lower == "°":
        quality = "dim"
    elif remainder_lower.startswith("aug") or remainder_lower == "+":
        quality = "aug"
    elif remainder_lower.startswith("sus2"):
        quality = "sus2"
    elif remainder_lower.startswith("sus4") or remainder_lower.startswith("sus"):
        quality = "sus4"
    elif remainder_lower.startswith("7"):
        quality = "7"
    elif remainder_lower.startswith("m") or remainder_lower.startswith("min"):
        quality = "min"
    elif remainder_lower.startswith("add9"):
        quality = "add9"
    elif remainder_lower.startswith("6") and not remainder_lower.startswith("69"):
        quality = "6"
    elif remainder_lower.startswith("9"):
        quality = "9"
    else:
        quality = "maj"
    return root, quality


def get_chord_pitches(root: str, quality: str, octave: int = 4) -> List[int]:
    root_midi = note_name_to_midi(root, octave)
    intervals = CHORD_INTERVALS.get(quality, CHORD_INTERVALS["maj"])
    return [root_midi + interval for interval in intervals]


def voice_distance(pitch1: int, pitch2: int) -> int:
    return abs(pitch1 - pitch2)


def find_closest_pitch(target: int, candidates: List[int]) -> int:
    if not candidates:
        return target
    return min(candidates, key=lambda p: abs(p - target))


def check_parallel_motion(v1_prev: int, v1_curr: int, v2_prev: int, v2_curr: int, interval: int) -> bool:
    prev_interval = abs(v1_prev - v2_prev) % 12
    curr_interval = abs(v1_curr - v2_curr) % 12
    if prev_interval == interval % 12 and curr_interval == interval % 12:
        motion1 = v1_curr - v1_prev
        motion2 = v2_curr - v2_prev
        if motion1 != 0 and motion2 != 0:
            return (motion1 > 0) == (motion2 > 0)
    return False


def voice_close(pitches: List[int], num_voices: int, center: int = 60) -> List[int]:
    voiced = []
    pitch_classes = list(set(p % 12 for p in pitches))
    base_octave = (center // 12) * 12
    for i, pc in enumerate(pitch_classes[:num_voices]):
        midi = base_octave + pc
        while midi < center - 6:
            midi += 12
        while midi > center + 6:
            midi -= 12
        voiced.append(midi)
    while len(voiced) < num_voices:
        voiced.append(voiced[0] - 12 if voiced[0] > center else voiced[0] + 12)
    return sorted(voiced)


def voice_open(pitches: List[int], num_voices: int, center: int = 60) -> List[int]:
    voiced = []
    pitch_classes = list(set(p % 12 for p in pitches))
    spread_factor = 12
    base = center - (num_voices * spread_factor) // 2
    for i, pc in enumerate(pitch_classes[:num_voices]):
        octave = base + (i * spread_factor)
        midi = (octave // 12) * 12 + pc
        voiced.append(midi)
    while len(voiced) < num_voices:
        voiced.append(voiced[0] - 12)
    return sorted(voiced)


def voice_drop_2(pitches: List[int], num_voices: int, center: int = 60) -> List[int]:
    close = voice_close(pitches, num_voices, center)
    if len(close) >= 4:
        close_desc = sorted(close, reverse=True)
        close_desc[1] -= 12
        return sorted(close_desc)
    return close


def voice_spread(pitches: List[int], num_voices: int, center: int = 60) -> List[int]:
    voiced = []
    pitch_classes = list(set(p % 12 for p in pitches))
    bass_octave = center - 24
    voiced.append((bass_octave // 12) * 12 + pitch_classes[0])
    remaining = num_voices - 1
    spread = 36 // max(1, remaining)
    for i, pc in enumerate(pitch_classes[1:num_voices]):
        octave = center - 12 + (i * spread)
        midi = (octave // 12) * 12 + pc
        voiced.append(midi)
    while len(voiced) < num_voices:
        voiced.append(voiced[-1] + 12)
    return sorted(voiced)


def voice_cluster(pitches: List[int], num_voices: int, center: int = 60) -> List[int]:
    voiced = []
    pitch_classes = list(set(p % 12 for p in pitches))
    current = center
    for pc in pitch_classes[:num_voices]:
        midi = (current // 12) * 12 + pc
        while midi > current + 4:
            midi -= 12
        while midi < current - 2:
            midi += 12
        voiced.append(midi)
        current = midi + 2
    while len(voiced) < num_voices:
        voiced.append(voiced[-1] + 2)
    return sorted(voiced)


def voice_rootless(pitches: List[int], num_voices: int, center: int = 60) -> List[int]:
    pitch_classes = list(set(p % 12 for p in pitches))
    if len(pitch_classes) > 1:
        pitch_classes = pitch_classes[1:]
    return voice_close([center + pc for pc in pitch_classes], num_voices, center)


VOICING_FUNCTIONS = {
    VoicingStyle.CLOSE: voice_close,
    VoicingStyle.OPEN: voice_open,
    VoicingStyle.DROP_2: voice_drop_2,
    VoicingStyle.DROP_3: voice_drop_2,
    VoicingStyle.SPREAD: voice_spread,
    VoicingStyle.CLUSTER: voice_cluster,
    VoicingStyle.ROOTLESS: voice_rootless,
}


class VoiceLeadingEngine:
    def __init__(self, custom_profiles: Optional[Dict] = None):
        self.profiles = EMOTION_VOICE_PROFILES.copy()
        if custom_profiles:
            self.profiles.update(custom_profiles)

    def voice_progression(self, chords: List[str], key: str = "C", emotion: str = "neutral",
                          num_voices: int = 4, **kwargs) -> VoiceLeadingOutput:
        config = VoiceConfig(emotion=emotion.lower(), num_voices=num_voices, key=key, **kwargs)
        return self._voice_from_config(chords, config)

    def _voice_from_config(self, chords: List[str], config: VoiceConfig) -> VoiceLeadingOutput:
        if config.seed is not None:
            random.seed(config.seed)

        profile = self.profiles.get(config.emotion, self.profiles["neutral"])
        voicing_style = config.voicing_override or random.choice(profile["voicing_style"])
        voicing_func = VOICING_FUNCTIONS.get(voicing_style, voice_close)

        register_centers = {"low": 48, "mid": 60, "high": 72, "varied": 60}
        center = register_centers.get(profile["preferred_register"], 60)

        voiced_chords = []
        prev_voicing = None
        total_movement = 0
        rules_broken = []

        for chord_str in chords:
            root, quality = parse_chord(chord_str)
            chord_pitches = get_chord_pitches(root, quality, 4)
            raw_voicing = voicing_func(chord_pitches, config.num_voices, center)

            if prev_voicing is not None:
                voiced_pitches = self._apply_voice_leading(prev_voicing, raw_voicing, profile, config)
                for p1, p2 in zip(prev_voicing, voiced_pitches):
                    total_movement += voice_distance(p1, p2)
                if config.allow_rule_breaking:
                    for i in range(len(prev_voicing) - 1):
                        for j in range(i + 1, len(prev_voicing)):
                            if check_parallel_motion(prev_voicing[i], voiced_pitches[i],
                                                     prev_voicing[j], voiced_pitches[j], 7):
                                if VoiceLeadingRule.NO_PARALLEL_5THS in profile["rules_to_break"]:
                                    rules_broken.append(VoiceLeadingRule.NO_PARALLEL_5THS)
            else:
                voiced_pitches = raw_voicing

            has_suspension = random.random() < profile["suspension_probability"]
            has_anticipation = random.random() < profile["anticipation_probability"]

            voices = []
            voice_names = ["bass", "tenor", "alto", "soprano"][:config.num_voices]
            chord_functions = ["root", "third", "fifth", "seventh"]
            intervals = CHORD_INTERVALS.get(quality, [0, 4, 7])

            for i, pitch in enumerate(sorted(voiced_pitches)):
                pc = pitch % 12
                root_pc = note_name_to_midi(root, 0) % 12
                relative_pc = (pc - root_pc) % 12
                if relative_pc in intervals:
                    func_idx = intervals.index(relative_pc)
                    func = chord_functions[func_idx] if func_idx < len(chord_functions) else "extension"
                else:
                    func = "chromatic"
                voice = Voice(pitch=pitch, voice_name=voice_names[i] if i < len(voice_names) else f"voice_{i}",
                              chord_function=func, is_doubled=voiced_pitches.count(pitch) > 1)
                voices.append(voice)

            vc = VoicedChord(symbol=chord_str, root=note_name_to_midi(root, 4), quality=quality,
                            voices=voices, bass_note=min(voiced_pitches), voicing_style=voicing_style,
                            has_suspension=has_suspension, has_anticipation=has_anticipation)
            voiced_chords.append(vc)
            prev_voicing = voiced_pitches

        max_possible_movement = len(chords) * config.num_voices * 12
        smoothness = 1.0 - (total_movement / max(1, max_possible_movement))

        return VoiceLeadingOutput(voiced_chords=voiced_chords, config=config, voicing_style_used=voicing_style,
                                  rules_broken=list(set(rules_broken)), total_voice_movement=total_movement,
                                  smoothness_score=smoothness)

    def _apply_voice_leading(self, prev: List[int], target: List[int], profile: Dict,
                             config: VoiceConfig) -> List[int]:
        result = []
        used_targets = set()
        for prev_pitch in sorted(prev):
            available = [t for t in target if t not in used_targets]
            if not available:
                available = target
            if VoiceLeadingRule.SMOOTH_MOTION not in profile.get("rules_to_break", []):
                best = find_closest_pitch(prev_pitch, available)
            else:
                best = random.choice(available)
            if prev_pitch in target and VoiceLeadingRule.COMMON_TONES not in profile.get("rules_to_break", []):
                best = prev_pitch
            result.append(best)
            used_targets.add(best)
        while len(result) < len(target):
            for t in target:
                if t not in result:
                    result.append(t)
                    break
        return sorted(result)

    def voice_single_chord(self, chord: str, emotion: str = "neutral", num_voices: int = 4,
                           center: int = 60) -> VoicedChord:
        output = self.voice_progression([chord], emotion=emotion, num_voices=num_voices)
        return output.voiced_chords[0]
