"""
MIDI Export - Writes generated music to MIDI files.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple, BinaryIO
import struct
import io


TICKS_PER_BEAT = 480

# General MIDI drum map
GM_DRUMS = {
    "kick": 36,
    "snare": 38,
    "hihat_closed": 42,
    "hihat_open": 46,
    "hihat": 42,
    "tom_low": 45,
    "tom_mid": 47,
    "tom_high": 50,
    "crash": 49,
    "ride": 51,
    "clap": 39,
}

# General MIDI instruments
GM_INSTRUMENTS = {
    "piano": 0,
    "bright_piano": 1,
    "electric_piano": 4,
    "harpsichord": 6,
    "organ": 19,
    "guitar_acoustic": 24,
    "guitar_electric": 27,
    "bass_acoustic": 32,
    "bass_electric": 33,
    "strings": 48,
    "ensemble": 49,
    "brass": 61,
    "synth_lead": 80,
    "synth_pad": 88,
}


@dataclass
class MidiNote:
    pitch: int
    start_tick: int
    duration_ticks: int
    velocity: int
    channel: int = 0


@dataclass
class MidiTrack:
    name: str
    notes: List[MidiNote]
    instrument: int = 0
    channel: int = 0


class MidiWriter:
    """Writes MIDI files from generated music data."""

    def __init__(self, ticks_per_beat: int = TICKS_PER_BEAT):
        self.ticks_per_beat = ticks_per_beat

    def write_variable_length(self, value: int) -> bytes:
        """Encode value as MIDI variable-length quantity."""
        result = []
        result.append(value & 0x7F)
        value >>= 7
        while value:
            result.append((value & 0x7F) | 0x80)
            value >>= 7
        return bytes(reversed(result))

    def create_track(self, events: List[Tuple[int, bytes]]) -> bytes:
        """Create a MIDI track from sorted events."""
        data = io.BytesIO()

        # Sort events by tick
        events = sorted(events, key=lambda x: x[0])

        prev_tick = 0
        for tick, event_data in events:
            delta = tick - prev_tick
            data.write(self.write_variable_length(delta))
            data.write(event_data)
            prev_tick = tick

        # End of track
        data.write(self.write_variable_length(0))
        data.write(b'\xFF\x2F\x00')

        track_data = data.getvalue()

        # Track header
        header = b'MTrk' + struct.pack('>I', len(track_data))
        return header + track_data

    def note_on(self, channel: int, pitch: int, velocity: int) -> bytes:
        """Create note on event."""
        return bytes([0x90 | (channel & 0x0F), pitch & 0x7F, velocity & 0x7F])

    def note_off(self, channel: int, pitch: int) -> bytes:
        """Create note off event."""
        return bytes([0x80 | (channel & 0x0F), pitch & 0x7F, 0])

    def program_change(self, channel: int, program: int) -> bytes:
        """Create program change event."""
        return bytes([0xC0 | (channel & 0x0F), program & 0x7F])

    def tempo_event(self, bpm: int) -> bytes:
        """Create tempo meta event."""
        microseconds = int(60_000_000 / bpm)
        return bytes([0xFF, 0x51, 0x03,
                      (microseconds >> 16) & 0xFF,
                      (microseconds >> 8) & 0xFF,
                      microseconds & 0xFF])

    def time_signature_event(self, numerator: int, denominator: int) -> bytes:
        """Create time signature meta event."""
        denom_power = {1: 0, 2: 1, 4: 2, 8: 3, 16: 4}.get(denominator, 2)
        return bytes([0xFF, 0x58, 0x04, numerator, denom_power, 24, 8])

    def track_name_event(self, name: str) -> bytes:
        """Create track name meta event."""
        name_bytes = name.encode('ascii', errors='ignore')[:127]
        return bytes([0xFF, 0x03, len(name_bytes)]) + name_bytes

    def write_file(self, tracks: List[MidiTrack], tempo: int = 120,
                   time_signature: Tuple[int, int] = (4, 4),
                   filename: Optional[str] = None) -> bytes:
        """Write complete MIDI file."""
        output = io.BytesIO()

        # Header chunk
        num_tracks = len(tracks) + 1  # +1 for tempo track
        format_type = 1 if num_tracks > 1 else 0

        header = b'MThd'
        header += struct.pack('>I', 6)  # Chunk length
        header += struct.pack('>HHH', format_type, num_tracks, self.ticks_per_beat)
        output.write(header)

        # Tempo track
        tempo_events = [
            (0, self.tempo_event(tempo)),
            (0, self.time_signature_event(*time_signature)),
        ]
        output.write(self.create_track(tempo_events))

        # Music tracks
        for track in tracks:
            events = []

            # Track name
            if track.name:
                events.append((0, self.track_name_event(track.name)))

            # Program change (instrument)
            if track.channel != 9:  # Not drums
                events.append((0, self.program_change(track.channel, track.instrument)))

            # Notes
            for note in track.notes:
                events.append((note.start_tick, self.note_on(track.channel, note.pitch, note.velocity)))
                events.append((note.start_tick + note.duration_ticks,
                               self.note_off(track.channel, note.pitch)))

            output.write(self.create_track(events))

        midi_data = output.getvalue()

        if filename:
            with open(filename, 'wb') as f:
                f.write(midi_data)

        return midi_data


class MidiExporter:
    """High-level MIDI export from Kelly Companion output."""

    def __init__(self):
        self.writer = MidiWriter()

    def export_voiced_progression(self, voiced_chords, tempo: int = 120,
                                   beats_per_chord: float = 4.0,
                                   instrument: str = "piano",
                                   filename: Optional[str] = None) -> bytes:
        """Export voiced chord progression to MIDI."""
        notes = []

        tick = 0
        duration = int(beats_per_chord * TICKS_PER_BEAT)

        for vc in voiced_chords:
            for voice in vc.voices:
                notes.append(MidiNote(
                    pitch=voice.pitch,
                    start_tick=tick,
                    duration_ticks=duration - 10,  # Slight gap
                    velocity=80,
                    channel=0
                ))
            tick += duration

        track = MidiTrack(
            name="Chords",
            notes=notes,
            instrument=GM_INSTRUMENTS.get(instrument, 0),
            channel=0
        )

        return self.writer.write_file([track], tempo, filename=filename)

    def export_melody(self, melody_output, tempo: int = 120,
                      instrument: str = "piano",
                      filename: Optional[str] = None) -> bytes:
        """Export melody to MIDI."""
        notes = []

        for event in melody_output.to_midi_events():
            pitch, start, duration, velocity = event
            notes.append(MidiNote(
                pitch=pitch,
                start_tick=int(start * TICKS_PER_BEAT),
                duration_ticks=int(duration * TICKS_PER_BEAT),
                velocity=velocity,
                channel=0
            ))

        track = MidiTrack(
            name="Melody",
            notes=notes,
            instrument=GM_INSTRUMENTS.get(instrument, 0),
            channel=0
        )

        return self.writer.write_file([track], tempo, filename=filename)

    def export_drums(self, drum_pattern, filename: Optional[str] = None) -> bytes:
        """Export drum pattern to MIDI."""
        tracks = []

        # Kick
        kick_notes = []
        for event in drum_pattern.kick.events:
            if not event.is_rest:
                kick_notes.append(MidiNote(
                    pitch=GM_DRUMS["kick"],
                    start_tick=int(event.start_beat * TICKS_PER_BEAT),
                    duration_ticks=int(event.duration * TICKS_PER_BEAT),
                    velocity=event.velocity,
                    channel=9
                ))
        tracks.append(MidiTrack("Kick", kick_notes, channel=9))

        # Snare
        snare_notes = []
        for event in drum_pattern.snare.events:
            if not event.is_rest:
                snare_notes.append(MidiNote(
                    pitch=GM_DRUMS["snare"],
                    start_tick=int(event.start_beat * TICKS_PER_BEAT),
                    duration_ticks=int(event.duration * TICKS_PER_BEAT),
                    velocity=event.velocity,
                    channel=9
                ))
        tracks.append(MidiTrack("Snare", snare_notes, channel=9))

        # Hi-hat
        hihat_notes = []
        for event in drum_pattern.hihat.events:
            if not event.is_rest:
                hihat_notes.append(MidiNote(
                    pitch=GM_DRUMS["hihat"],
                    start_tick=int(event.start_beat * TICKS_PER_BEAT),
                    duration_ticks=int(event.duration * TICKS_PER_BEAT),
                    velocity=event.velocity,
                    channel=9
                ))
        tracks.append(MidiTrack("Hi-Hat", hihat_notes, channel=9))

        return self.writer.write_file(tracks, drum_pattern.tempo, filename=filename)

    def export_full_composition(self, voiced_chords=None, melody_output=None,
                                drum_pattern=None, bass_notes=None,
                                tempo: int = 120, beats_per_chord: float = 4.0,
                                filename: Optional[str] = None) -> bytes:
        """Export full composition with multiple parts."""
        tracks = []

        # Chords
        if voiced_chords:
            chord_notes = []
            tick = 0
            duration = int(beats_per_chord * TICKS_PER_BEAT)

            for vc in voiced_chords:
                for voice in vc.voices:
                    chord_notes.append(MidiNote(
                        pitch=voice.pitch,
                        start_tick=tick,
                        duration_ticks=duration - 10,
                        velocity=70,
                        channel=0
                    ))
                tick += duration

            tracks.append(MidiTrack("Chords", chord_notes,
                                   instrument=GM_INSTRUMENTS["piano"], channel=0))

        # Melody
        if melody_output:
            melody_notes = []
            for event in melody_output.to_midi_events():
                pitch, start, duration, velocity = event
                melody_notes.append(MidiNote(
                    pitch=pitch,
                    start_tick=int(start * TICKS_PER_BEAT),
                    duration_ticks=int(duration * TICKS_PER_BEAT),
                    velocity=velocity,
                    channel=1
                ))
            tracks.append(MidiTrack("Melody", melody_notes,
                                   instrument=GM_INSTRUMENTS["piano"], channel=1))

        # Bass
        if bass_notes:
            bass_track_notes = []
            for note in bass_notes:
                bass_track_notes.append(MidiNote(
                    pitch=note["pitch"],
                    start_tick=int(note["start"] * TICKS_PER_BEAT),
                    duration_ticks=int(note["duration"] * TICKS_PER_BEAT),
                    velocity=note.get("velocity", 80),
                    channel=2
                ))
            tracks.append(MidiTrack("Bass", bass_track_notes,
                                   instrument=GM_INSTRUMENTS["bass_acoustic"], channel=2))

        # Drums
        if drum_pattern:
            for event in drum_pattern.kick.events:
                if not event.is_rest:
                    # Add to a combined drums track
                    pass  # Simplified - would add properly

        return self.writer.write_file(tracks, tempo, filename=filename)


def export_to_midi(voiced_chords, filename: str, tempo: int = 120) -> str:
    """Quick export convenience function."""
    exporter = MidiExporter()
    exporter.export_voiced_progression(voiced_chords, tempo, filename=filename)
    return filename
